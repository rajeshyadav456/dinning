# from .models import *
# from rest_framework import serializers


# class MyprofilesSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Myprofile
#         fields = "__all__"


# class KidsprofileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Kids_profile
#         fields = "__all__"
#         depth = 1


# class parentsandkidsdataSerializer(serializers.ModelSerializer):
#     kids_details = KidsprofileSerializer(many=True)
#     class Meta:
#         model  = Myprofile
#         fields = "__all__"

# class PlansavailableSerializer(serializers.ModelSerializer):
#     class Meta:
#        model  = Plans_available
#        fields = "__all__"
#        depth = 1


# class MembershipplansSerializer(serializers.ModelSerializer):
#     plan_available_weekends = PlansavailableSerializer(many=True)
#     class Meta:
#         model  = Membership_plan
#         fields = "__all__"
#         depth = 1





# class MypurchasesSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Selected_plans
#         fields = "__all__"
#         depth = 1


# class SuperSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Super
#         fields = "__all__"


# class SchoolslistingSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Schools_listing
#         fields = "__all__"


# class SchoolswithmembershiplistingSerializer(serializers.ModelSerializer):
#     plan_for_school = MembershipplansSerializer(many=True)
#     class Meta:
#         model  = Schools_listing
#         fields = "__all__"
#         depth = 1





# class WeeksSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Weeks
#         fields = "__all__"


# class GradesSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Grades
#         fields = "__all__"
#         depth = 1


# class GradedurationSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Grade_duration
#         fields = "__all__"
        

# class GradeswithschoolSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Grades
#         fields = "grades_id","name"


# class SchoolwithgradesSerializer(serializers.ModelSerializer):
#     school_details_according_to_grade = GradesSerializer(many=True)
#     class Meta:
#         model  = Schools_listing
#         fields = "__all__"


# class GradewithplansSerializer(serializers.ModelSerializer):
#     Grades_details = MembershipplansSerializer(many=True)
#     class Meta:
#         model  = Grades
#         fields = "__all__"


# class kidslistingwithgradesSerializer(serializers.ModelSerializer):
#     grades_for_student = KidsprofileSerializer(many=True)
#     class Meta:
#         model  = Grades
#         fields = "__all__"


# class PlansweeksavailableSerializer(serializers.ModelSerializer):
#     plan_available_weekends = PlansavailableSerializer(many=True)
#     class Meta:
#         model  = Membership_plan
#         fields = "__all__"


# class GradeswithplanSerializer(serializers.ModelSerializer):
#     plan_available_weekends = PlansavailableSerializer(many=True)
#     class Meta:
#         model  = Membership_plan
#         fields = "__all__"


# class StudentswithparentsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Kids_profile
#         fields = "__all__"
#         depth = 1


# class adddataSerializer(serializers.ModelSerializer):
#     class Meta:
#         model   = Super
#         fields = "__all__"

# class SelectedplansStatusSerializer(serializers.ModelSerializer):
#     class Meta:
#         model  = Selected_plans
#         fields = "__all__"


# class Membershipplanserilizer(serializers.ModelSerializer):
#     class Meta:
#         model = Membership_plan
#         fields = "__all__"
        
# class SelectedplansSerializer(serializers.ModelSerializer):
#     plan_id = Membershipplanserilizer()
#     class Meta:
#         model  = Selected_plans
#         fields = "__all__"


# class PlanslistingSerializer(serializers.ModelSerializer):
#     parents_details = SelectedplansSerializer(many=True)
#     class Meta:
#         model  = Myprofile
#         fields = "__all__"

# class SelectedplanswithparentsSerializer(serializers.ModelSerializer):
#     parents_details = SelectedplansSerializer(many=True)
#     class Meta:
#         model = Myprofile
#         fields = "__all__"

        
# class allpurchaseplansserializer(serializers.ModelSerializer):
#     plan_id = Membershipplanserilizer()
#     class Meta:
#         model = Selected_plans
#         fields = "__all__"
       