# from django.shortcuts import render,redirect
# from rest_framework.response import Response
# from rest_framework.decorators import api_view
# from django.db.models import Q
# from django.contrib.auth import logout
# import math
# from rest_framework import status
# from django.contrib import messages
# from django.contrib.auth import authenticate,login as login_me,logout as logout_me
# from rest_framework.views import APIView
# from rest_framework.response import Response
# import requests
# from .serializers import *
# from datetime import date, datetime, timedelta
# import jwt
# import random
# from django.conf import settings
# from django.core.mail import send_mail
# from .models import *
# from django.views.decorators.csrf import csrf_exempt
# from rest_framework_simplejwt.tokens import RefreshToken
# from django.utils import timezone
# from rest_framework import authentication
# # from pyfcm import FCMNotification
# @csrf_exempt
# # Create your views here.

# @api_view(["POST"])
# def create_user(request):
#     username = request.data['username']
#     password = request.data['password']
#     ftt = Myprofile.objects.create(username=username,password=password)
#     ftt.save()
#     serializer = MyprofilesSerializer(ftt)
#     return Response({"success":True, "message": "Sign up Successfully","data":serializer.data}, status=status.HTTP_200_OK)


# # @api_view(['POST'])
# # def user_login(request):
# #     if request.data['username_Code'] == "":
# #         return Response({"success":False, "message": "username_Code is required" }, status=status.HTTP_400_BAD_REQUEST) 
# #     username_Code = request.data['username_Code']
# #     if request.data['password']=="":
# #         return Response({"success":False, "message": "password is required"}, status=status.HTTP_400_BAD_REQUEST)
# #     password = request.data['password']
# #     if Myprofile.objects.filter(username_Code=username_Code,password=password).exists():
# #         user = Myprofile.objects.filter(username_Code=username_Code).first()
# #         profile_id =user.profile_id
# #         gogogo = {
# #                 'profile_id' : profile_id,
# #                 'exp': datetime.utcnow() + timedelta(days=365),
# #                 'iat': datetime.utcnow()
# #         }
# #         token = jwt.encode(gogogo, 'secret',algorithm='HS256')
# #         over = datetime.now()
# #         if Token_data.objects.filter(profile_id=user.profile_id).exists():
# #             lff = Token_data.objects.filter(profile_id=user.profile_id).first()
# #             lff.token=token
# #             lff.datetime = over
# #             lff.save()
# #         else:
# #             der = Token_data.objects.create(token=token,profile_id_id=user.profile_id,datetime=over)
# #             der.save()
# #         serializer = MyprofilesSerializer(user)
# #         return Response({"success":True, "message": "Logged In Successfully",'token':token,"data":serializer.data}, status=status.HTTP_200_OK)
# #     else:
# #         return Response({"success":False, "message": "Please Enter Valid Username or Password"},status=status.HTTP_401_UNAUTHORIZED)

#user code data

# @api_view(['POST'])
# def user_login(request):
#     if request.data['username_Code'] == "":
#         return Response({"success":False, "message": "username_Code is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     username_Code = request.data['username_Code']
#     if request.data['password']=="":
#         return Response({"success":False, "message": "password is required"}, status=status.HTTP_400_BAD_REQUEST)
#     password = request.data['password']
#     if Myprofile.objects.filter(username=username_Code,password=password).exists():
#         user = Myprofile.objects.filter(username=username_Code).first()
#         profile_id =user.profile_id
#         gogogo = {
#                 'profile_id' : profile_id,
#                 'exp': datetime.utcnow() + timedelta(days=365),
#                 'iat': datetime.utcnow()
#         }
#         token = jwt.encode(gogogo, 'secret',algorithm='HS256')
#         over = datetime.now()
#         if Token_data.objects.filter(profile_id=user.profile_id).exists():
#             lff = Token_data.objects.filter(profile_id=user.profile_id).first()
#             lff.token=token
#             lff.datetime = over
#             lff.save()
#         else:
#             der = Token_data.objects.create(token=token,profile_id_id=user.profile_id,datetime=over)
#             der.save()
#         serializer = MyprofilesSerializer(user)
#         return Response({"success":True, "message": "Logged In Successfully",'token':token,"data":serializer.data}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "Please Enter Valid Username or Password"},status=status.HTTP_401_UNAUTHORIZED)

# @api_view(['GET'])
# def get_user(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         user = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         serializer = MyprofilesSerializer(user)
#         x = serializer.data
#         return Response({"success":True, "message": "Here is your profile","data":x}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# @api_view(["POST"])
# def basic_information(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         user = member.profile_id
#         if (member):
#             user = Myprofile.objects.get(profile_id=payload['profile_id'])
#             profile_pic = request.data["profile_pic"]
#             full_name = request.data["full_name"] 
#             email = request.data['email']
#             contact_no = request.data['contact_no']
#             user_status = request.data['user_status']
#             if profile_pic:
#                 if "/" in profile_pic:
#                     profile_pic = profile_pic
#                 else:
#                     user.profile_pic = profile_pic
#             if full_name:
#                 user.full_name = full_name
#             if email:
#                 user.email = email
#             if contact_no:
#                 user.contact_no =contact_no
#             if user_status:
#                 user.status = user_status
#             user.save()
#             profile_id = user.profile_id
#             user = Myprofile.objects.get(profile_id=profile_id)
#             serializer = MyprofilesSerializer(user)
#             return Response({"success":True, "message": "Your profile is completed successfully","data":serializer.data},status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "Please enter valid Token id"},status=status.HTTP_401_UNAUTHORIZED)          
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)       


# @api_view(["POST"])
# def kids_information(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         user = member.profile_id
#         if (member):
#             school_id = request.data['school_id']
#             grades_id = request.data['grades_id']
#             kid_profile_pic = request.data['kid_profile_pic']
#             kid_full_name = request.data['kid_full_name']
#             roll_no = request.data["roll_no"]
#             dob = request.data['dob']
#             bio = request.data['bio'] 
#             user = Kids_profile.objects.create(profile_id_id=member.profile_id,grades_id_id=grades_id,school_id_id=school_id,kid_profile_pic=kid_profile_pic,kid_full_name=kid_full_name,roll_no=roll_no,dob=dob,bio=bio)
#             dtt = user.kds_profile_id
#             serializer = KidsprofileSerializer(dtt)
#             return Response({"success":True, "message": "kids details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "Please enter valid Token id"},status=status.HTTP_401_UNAUTHORIZED)          
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)


# @api_view(["POST"])
# def edit_kids_information(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         user = member.profile_id
#         if (member):
#             if request.data['kds_profile_id'] == "":
#                 return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#             kds_profile_id = request.data['kds_profile_id']
#             user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
#             school_id = request.data['school_id']
#             grades_id = request.data['grades_id']
#             kid_profile_pic = request.data['kid_profile_pic']
#             kid_full_name = request.data['kid_full_name']
#             roll_no = request.data["roll_no"]
#             dob = request.data['dob']
#             bio = request.data['bio']
#             if school_id:
#                 user.school_id_id= school_id
#             if grades_id:
#                 user.grades_id_id= grades_id
#             if kid_profile_pic:
#                 if "/" in kid_profile_pic:
#                     kid_profile_pic = kid_profile_pic
#                 else:
#                     user.kid_profile_pic = kid_profile_pic
#             if kid_full_name:
#                 user.kid_full_name = kid_full_name
#             if roll_no:
#                 user.roll_no = roll_no
#             if dob:
#                 user.dob = dob
#             if bio:
#                 user.bio = bio
#             user.save()
#             serializer = KidsprofileSerializer(user)
#             return Response({"success":True, "message": "kids details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "Please enter valid Token id"},status=status.HTTP_401_UNAUTHORIZED)          
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)        


# @api_view(['GET'])
# def userschool_all_listing(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if member:
#             gt = Schools_listing.objects.all().order_by('-school_id')
#             lst =[]
#             for i in gt:
#                 rrr = Kids_profile.objects.filter(school_id=i.school_id).count()
#                 serializer = SchoolslistingSerializer(i)
#                 x = serializer.data
#                 x.update({"student_count":rrr})
#                 lst.append(x)
            
#             return Response({"success":True, "message": "Here is your school details","data":lst,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#         else:
#            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# @api_view(["GET"])
# def number_of_kids_listing(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         user = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if user:
#             serializer = parentsandkidsdataSerializer(user)
#             x = serializer.data
#             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "Kids not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST'])
# def membership_listing(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if member:
#             if request.data['school_id'] == "":
#                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
#             school_id = request.data['school_id']
#             if Schools_listing.objects.filter(school_id=school_id).exists():
#                 ltt = Schools_listing.objects.filter(school_id=school_id).first()
#                 serializer = SchoolswithmembershiplistingSerializer(ltt)
#                 return Response({"success":True, "message": "Here is your membership listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#             else:
#                return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
#         else:   
#             return Response({"success":True, "message": "Token is expired or invalid"}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST) 
    

# @api_view(["POST"])
# def get_membership(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if (member):
#             user = Myprofile.objects.get(profile_id=payload['profile_id'])
#             if request.data['plan_id'] == "":
#                 return Response({"success":False, "message": "plan_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#             plan_id = request.data['plan_id']
#             if request.data['kds_profile_id'] == "":
#                 return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#             kds_profile_id = request.data['kds_profile_id']
#             fill = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
            
#             fill.status = 1
#             ldd = Selected_plans.objects.create(plan_id_id=plan_id,profile_id_id=user.profile_id,kds_profile_id_id=kds_profile_id)
#             ldd.save()
#             return Response({"success":True,"message": "Plan has been added successfully."}, status=status.HTTP_200_OK)
#         else:
#             return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)


# @api_view(["GET"])
# def my_plan_listing(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if (member):
#             user = Myprofile.objects.get(profile_id=payload['profile_id'])
#             plans = Selected_plans.objects.filter(profile_id=user.profile_id)
#             serializer = PlanslistingSerializer(user)
#             x = serializer.data
#             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST'])
# def edit_profile(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if (member):
#             user = Myprofile.objects.get(profile_id=payload['profile_id'])
#             profile_pic = request.data["profile_pic"]
#             full_name = request.data["full_name"] 
#             email = request.data['email']
#             expertise = request.data['expertise']
#             contact_no = request.data['contact_no']
#             if profile_pic:
#                 if "/" in profile_pic:
#                     profile_pic = profile_pic
#                 else:
#                     user.profile_pic = profile_pic
#             if full_name:
#                 user.full_name = full_name
#             if email:
#                 user.email = email
#             if expertise:
#                 user.expertise = expertise
#             if contact_no:
#                 user.contact_no = contact_no
#             user.save()
#             serializer = MyprofilesSerializer(user)
#             x = serializer.data
#             return Response({"success":True, "message": "Profile updated successfully","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST'])
# def setting_password_change(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         member = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if (member):
#             profile_id = member.profile_id
#             if request.data["old_password"]=="":
#                 return Response({"success":False, "message": "old_password is required" }, status=status.HTTP_400_BAD_REQUEST)
#             old_password = request.data['old_password']
#             if request.data['new_password']=="":
#                 return Response({"success":False, "message": "password is required" }, status=status.HTTP_400_BAD_REQUEST)
#             new_password = request.data['new_password']
#             if request.data['conferm_password']=="":
#                 return Response({"success":False, "message": "conferm password is required" }, status=status.HTTP_400_BAD_REQUEST)
#             conferm_password = request.data['conferm_password']
#             if Myprofile.objects.filter(profile_id=profile_id,password=old_password).exists():
#                 if new_password==conferm_password:
#                     mvp = Myprofile.objects.filter(profile_id=profile_id).first()
#                     mvp.password = new_password
#                     mvp.save()
#                     return Response({"success":True, "message": "Password changed successfully"}, status=status.HTTP_200_OK) 
#                 else:
#                   return Response({"success":False, "message": "password does'nt match properly"},status=status.HTTP_401_UNAUTHORIZED)         
#             else:
#                 return Response({"success":False, "message": "old password is invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         else:
#            return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required" }, status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST'])
# def single_kid_information(request):
#     if request.data['kds_profile_id']=="":
#         return Response({"success":False, "message": "kid_id is required" }, status=status.HTTP_400_BAD_REQUEST)
#     kds_profile_id = request.data['kds_profile_id']
#     user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
#     serializer = KidsprofileSerializer(user)
#     x = serializer.data
#     return Response({"success":True, "message": "Here is your profile","data":x}, status=status.HTTP_200_OK)
   

# @api_view(['POST'])
# def forget_password(request):
#     if request.data['email'] == "":
#         return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     email = request.data['email']
#     if Myprofile.objects.filter(email=email).exists():
#         email_from = settings.EMAIL_HOST_USER
#         recipient_list = [email]
#         subject = "One Time OTP"
#         otp = str(random.randint(1000, 9999))
#         print(otp)
#         message = "Your one time OTP is "
#         ms=message + otp
#         if Email_otp.objects.filter(email=email).exists():
#             nttp = Email_otp.objects.filter(email=email).first()
#             samma = timezone.now()
#             nttp.otp = otp
#             nttp.time = samma
#             nttp.save()
#         else:
#             query = Email_otp(email=email,otp=otp,time=timezone.now())
#             query.save()
#         send_mail( subject, ms, email_from, recipient_list)
#         return Response({"success":True, "message": "OTP send successfully"}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "Invalid Email"}, status=status.HTTP_401_UNAUTHORIZED)
 

# @api_view(['POST'])
# def verify_forget_pass(request):
#     if request.data['otp'] == "":
#         return Response({"success":False, "message": "Otp is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     otp = request.data['otp']
#     if request.data['email'] == "":
#         return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     email = request.data['email']
#     if Email_otp.objects.filter(otp=otp,email=email):
#         # ddty = Email_otp.objects.filter(otp=otp,email=email).first()
#         # start_time = ddty.time
#         # end_time = start_time + timedelta(minutes=int(5))
#         # end_time = datetime.strftime(end_time, '%Y-%m-%d %H:%M:%S')
#         # over = datetime.now()
#         # over = datetime.strftime(over, '%Y-%m-%d %H:%M:%S')
#         # if over >= end_time:
#         #     return Response({"success":False, "message": "OTP Expired" }, status=status.HTTP_401_UNAUTHORIZED)
        
#         return Response({"success":True, "message": "OTP verified successfully"}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "invalid OTP"}, status=status.HTTP_401_UNAUTHORIZED)


# @api_view(['POST'])
# def create_new_password(request):
#     if request.data['email'] == "":
#         return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     email = request.data['email']
#     if request.data['change_password']=="":
#             return Response({"success":False, "message": "password is required" }, status=status.HTTP_400_BAD_REQUEST)
#     change_password = request.data['change_password']
#     if request.data['confirm_password']=="":
#         return Response({"success":False, "message": "conferm password is required" }, status=status.HTTP_400_BAD_REQUEST)
#     confirm_password = request.data['confirm_password']
#     if Myprofile.objects.filter(email=email).first():
#         if change_password==confirm_password:
#             mvp = Myprofile.objects.filter(email=email).first()
#             mvp.password = confirm_password
#             mvp.save()
#             return Response({"success":True, "message": "Password changed successfully"}, status=status.HTTP_200_OK) 
#         else:
#           return Response({"success":False, "message": "password does'nt match properly"},status=status.HTTP_401_UNAUTHORIZED)
#     else:
#         return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        

# @api_view(["POST"])
# def school_with_grades(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         user = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if user:
#             if request.data['school_id']=="":
#                 return Response({"success":False, "message": "school_id is required" }, status=status.HTTP_400_BAD_REQUEST)
#             school_id = request.data['school_id']
#             ltt = Schools_listing.objects.filter(school_id=school_id).first()
#             serializer = SchoolwithgradesSerializer(ltt)
#             x = serializer.data
#             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "Kids not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# @api_view(["POST"])
# def grade_with_planlisting(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         user = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if user:
#             if request.data['grades_id']=="":
#                 return Response({"success":False, "message": "grades_id is required" }, status=status.HTTP_400_BAD_REQUEST)
#             grades_id = request.data['grades_id']
#             ltt = Grades.objects.filter(grades_id=grades_id).first()
#             serializer = GradewithplansSerializer(ltt)
#             x = serializer.data
#             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "parent not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# @api_view(["POST"])
# def get_plan_details(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid"},status=status.HTTP_401_UNAUTHORIZED)
#         user = Myprofile.objects.filter(profile_id=payload['profile_id']).first()
#         if user:
#             if request.data['plan_id']=="":
#                 return Response({"success":False, "message": "plan_id is required" }, status=status.HTTP_400_BAD_REQUEST)
#             plan_id = request.data['plan_id']
#             ltt = Membership_plans.objects.filter(plan_id=plan_id).first()
#             serializer = MembershipplansSerializer(ltt)
#             x = serializer.data
#             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "parent not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# # # ================================ADMIN PANEL========================================================


# # @api_view(["POST"])
# # def admin_login(request):
# #     if request.data['username'] == "":
# #         return Response({"success":False, "message": "username is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #     username = request.data['username']
# #     if request.data['password']=="":
# #         return Response({"success":False, "message": "password is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
# #     password = request.data['password']
# #     if Super.objects.filter(username=username,password=password).exists():
# #         user = Super.objects.filter(username=username).first()
# #         super_id =user.super_id
# #         gogogo = {
# #                 'super_id' : super_id,
# #                 'exp': datetime.utcnow() + timedelta(days=365),
# #                 'iat': datetime.utcnow()
# #         }
# #         token = jwt.encode(gogogo, 'secret',algorithms='HS256')
# #         return Response({"success":True, "message": "Logged In Successfully",'token':token,'status':status.HTTP_200_OK}, status=status.HTTP_200_OK)
# #     else:
# #         return Response({"success":False, "message": "Please Enter Valid Username or Password","status":status.HTTP_400_BAD_REQUEST},status=status.HTTP_400_BAD_REQUEST)


# # @api_view(["GET"])
# # def getprofile_admin(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         user = Super.objects.filter(super_id=payload['super_id']).first()
# #         serializer = SuperSerializer(user)
# #         x = serializer.data
# #         return Response({"success":True, "message": "Here is your profile","data":x,'status':status.HTTP_200_OK}, status=status.HTTP_200_OK)
# #     else:
# #         return Response({"success":False, "message": "Token is required",'status':status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def adminedit_profile(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             user = Super.objects.get(super_id=payload['super_id'])
# #             profile_pic = request.data["profile_pic"]
# #             full_name = request.data["full_name"] 
# #             address = request.data["address"]
# #             email = request.data['email']
# #             country_code = request.data['country_code']
# #             phone_number = request.data['phone_number']
# #             if profile_pic:
# #                 if "/" in profile_pic:
# #                     profile_pic = profile_pic
# #                 else:
# #                     user.profile_pic = profile_pic
# #             if full_name:
# #                 user.full_name = full_name
# #             if address:
# #                 user.address = address
# #             if email:
# #                 user.email = email
# #             if country_code:
# #                 user.country_code = country_code
# #             if phone_number:
# #                 user.phone_number = phone_number
# #             user.save()
# #             serializer = SuperSerializer(user)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Profile updated successfully","data":x,"status":status.HTTP_200_OK}, status=status.HTTP_200_OK)
# #         else:
# #             return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)



# # @api_view(["GET"])
# # def dashboard_admin(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             user = Super.objects.get(super_id=payload['super_id'])
# #             total_schools = Schools_listing.objects.all().count()
# #             total_parents = Myprofile.objects.all().count()
# #             total_students = Kids_profile.objects.all().count()
# #             total_plans = Membership_plans.objects.all().count()
# #             total_purchase = Selected_plans.objects.all().count()
# #             return Response({"success":True, "message": "Here is your dashboard details","total_schools":total_schools,"total_parents":total_parents,"total_students":total_students,"total_plans":total_plans,"total_purchase":total_purchase,"status":status.HTTP_200_OK}, status=status.HTTP_200_OK)
# #         else:
# #             return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def add_school_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             school_name = request.data["school_name"]
# #             image = request.data['image']
# #             email = request.data['email']
# #             country_code = request.data['country_code']
# #             contact_number = request.data['contact_number']
# #             select_country = request.data['select_country']
# #             select_state  = request.data['select_state']
# #             select_city = request.data['select_city']
# #             postal_code = request.data['postal_code']
# #             street_number = request.data['street_number']
# #             apartment_number = request.data['apartment_number']
# #             dtt = slice(5)
# #             usern = school_name[dtt]
# #             ame = random.randint(10000,99999)
# #             ldt = str(ame)
# #             username = usern+ldt
# #             ltt = Schools_listing.objects.create(school_name=school_name,image=image,email=email,country_code=country_code,contact_number=contact_number,select_country=select_country,select_state=select_state,select_city=select_city,postal_code=postal_code,street_number=street_number,apartment_number=apartment_number,username_Code=username)
# #             ltt.save()
# #             data = Schools_listing.objects.get(school_id=ltt.school_id)
# #             serializer = SchoolslistingSerializer(data)
# #             return Response({"success":True, "message": "school details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def getschool_details(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['school_id'] == "":
# #                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             school_id = request.data['school_id']
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 ltt = Schools_listing.objects.filter(school_id=school_id).first()
# #                 serializer = SchoolslistingSerializer(ltt)
# #                 return Response({"success":True, "message": "Here is your school details","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def update_school_detail(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['school_id'] == "":
# #                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             school_id = request.data['school_id']
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 user = Schools_listing.objects.filter(school_id=school_id).first()
# #                 school_name = request.data["school_name"]
# #                 image = request.data['image']
# #                 email = request.data['email']
# #                 country_code = request.data['country_code']
# #                 contact_number = request.data['contact_number']
# #                 select_country = request.data['select_country']
# #                 select_state  = request.data['select_state']
# #                 select_city = request.data['select_city']
# #                 postal_code = request.data['postal_code']
# #                 street_number = request.data['street_number']
# #                 apartment_number = request.data['apartment_number']
# #                 if school_name:
# #                     user.school_name = school_name
# #                 if image:
# #                     if "/" in image:
# #                         image = image
# #                     else:
# #                         user.image = image
# #                 if email:
# #                     user.email = email
# #                 if country_code:
# #                     user.country_code = country_code
# #                 if contact_number:
# #                     user.contact_number = contact_number
# #                 if select_country:
# #                     user.select_country = select_country
# #                 if select_state:
# #                     user.select_state = select_state
# #                 if select_city:
# #                     user.select_city = select_city
# #                 if postal_code:
# #                     user.postal_code = postal_code
# #                 if street_number:
# #                     user.street_number = street_number
# #                 if apartment_number:
# #                     user.apartment_number = apartment_number
# #                 user.save()
# #                 serializer = SchoolslistingSerializer(user)
# #                 return Response({"success":True, "message": "school details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def deleteschool(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['school_id'] == "":
# #                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             school_id = request.data['school_id']
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 user = Schools_listing.objects.filter(school_id=school_id).first()
# #                 user.delete()
# #                 return Response({"success":True, "message": "school details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['GET'])
# # def school_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             gt = Schools_listing.objects.all().order_by('-school_id')
# #             lst =[]
# #             for i in gt:
# #                 rrr = Kids_profile.objects.filter(school_id=i.school_id).count()
# #                 serializer = SchoolslistingSerializer(i)
# #                 x = serializer.data
# #                 x.update({"student_count":rrr})
# #                 lst.append(x)
            
# #             return Response({"success":True, "message": "Here is your school details","data":lst,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def adminadd_kids(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             school_id = request.data['school_id']
# #             kid_profile_pic = request.data['kid_profile_pic']
# #             kid_full_name = request.data['kid_full_name']
# #             roll_no = request.data["roll_no"]
# #             dob = request.data['dob']
# #             grades_id = request.data['grades_id']
# #             dtt = slice(6)
# #             usern = kid_full_name[dtt]
# #             ldt = str(roll_no)
# #             username = usern+ldt

# #             kkk = Kids_profile.objects.create(school_id_id=school_id,kid_profile_pic=kid_profile_pic,kid_full_name=kid_full_name,roll_no=roll_no,dob=dob,grades_id_id=grades_id,username_Code=username)
# #             serializer = KidsprofileSerializer(kkk)
# #             return Response({"success":True, "message": "kids details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def getkids_details(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['kds_profile_id'] == "":
# #                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             kds_profile_id = request.data['kds_profile_id']
# #             if Kids_profile.objects.filter(kds_profile_id=kds_profile_id).exists():
# #                 ltt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
# #                 serializer = KidsprofileSerializer(ltt)       
# #                 return Response({"success":True, "message": "kid details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "kid profile does'nt exist or invalid kid id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def kidsupdate_details(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['kds_profile_id'] == "":
# #                 return Response({"success":False, "message": "kds_profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             kds_profile_id = request.data['kds_profile_id']
# #             if Kids_profile.objects.filter(kds_profile_id=kds_profile_id).exists():
# #                 user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
# #                 school_id = request.data["school_id"]
# #                 grades_id = request.data['grades_id']
# #                 kid_profile_pic = request.data['kid_profile_pic']
# #                 kid_full_name = request.data["kid_full_name"]
# #                 roll_no = request.data["roll_no"]
# #                 dob = request.data['dob']
# #                 if school_id:
# #                     user.school_id_id= school_id
# #                 if grades_id:
# #                     user.grades_id_id = grades_id
# #                 if kid_profile_pic:
# #                     if "/" in kid_profile_pic:
# #                         kid_profile_pic = kid_profile_pic
# #                     else:
# #                         user.kid_profile_pic = kid_profile_pic
# #                 if kid_full_name:
# #                     user.kid_full_name = kid_full_name
# #                 if roll_no:
# #                     user.roll_no = roll_no
# #                 if dob:
# #                     user.dob = dob
# #                 user.save()
# #                 serializer = KidsprofileSerializer(user)
# #                 return Response({"success":True, "message": "kid details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "kid details does'nt exist or invalid kid id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)



# # @api_view(["POST"])
# # def delete_kids_details(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['kds_profile_id'] == "":
# #                 return Response({"success":False, "message": "kds_profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             kds_profile_id = request.data['kds_profile_id']
# #             if Kids_profile.objects.filter(kds_profile_id=kds_profile_id).exists():
# #                 user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
# #                 user.delete()
# #                 return Response({"success":True, "message": "kid details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "kid details does'nt exist or invalid kid id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['GET'])
# # def adminside_kids_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             lst = []
# #             gt = Kids_profile.objects.all().order_by("-kds_profile_id")
# #             for i in gt:
# #                 ddt = i.school_id.school_name
# #                 serializer = KidsprofileSerializer(i)
# #                 x = serializer.data
# #                 x.update({"school_name":ddt})
# #                 lst.append(x)
# #             return Response({"success":True, "message": "Here is your kids listing","data":lst,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def addparent_admin(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             kids_id = request.data["kids_id"]
# #             schoolkionly_id = request.data["schoolkionly_id"]
# #             gradekionly_id = request.data['gradekionly_id']
# #             full_name = request.data['full_name']
# #             email = request.data['email']
# #             password = request.data['password']
# #             dtt = slice(4)
# #             usern = full_name[dtt]
# #             ame = random.randint(10000,99999)
# #             ldt = str(ame)
# #             username = usern+ldt
# #             ltt = Myprofile.objects.create(schoolkionly_id=schoolkionly_id,gradekionly_id=gradekionly_id,full_name=full_name,email=email,password=password,username_Code=username)
# #             print(ltt , "LTTTTTTT")
# #             profile_id = ltt.profile_id
# #             print(profile_id)
# #             lst = kids_id.split(",")
# #             print(lst , "WWWWWWWWWW")
# #             for i in lst:
# #                 if (Kids_profile.objects.filter(kds_profile_id=i).first()):
# #                     rko = Kids_profile.objects.filter(kds_profile_id=i).first()
# #                     rko.profile_id.profile_id= profile_id
# #                     rko.save()
# #                 else:
# #                     return Response({"message": "kids Id not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)   
            
# #             data = Myprofile.objects.get(profile_id=ltt.profile_id)
# #             serializer = MyprofilesSerializer(data)
# #             return Response({"success":True, "message": "parents details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def getparent_details(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['profile_id'] == "":
# #                 return Response({"success":False, "message": "profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             profile_id = request.data['profile_id']
# #             if Myprofile.objects.filter(profile_id=profile_id).exists():
# #                 ltt = Myprofile.objects.filter(profile_id=profile_id).first()
# #                 serializer = parentsandkidsdataSerializer(ltt)
# #                 x = serializer.data
# #                 y = x["kids_details"]
# #                 for i in y:
# #                     i.pop("profile_id")
# #                 return Response({"success":True, "message": "parents details added successfully","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "parents profile does'nt exist or invalid parents id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #             return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def editparent_profile(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['profile_id'] == "":
# #                 return Response({"success":False, "message": "kds_profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             profile_id = request.data['profile_id']
# #             if Myprofile.objects.filter(profile_id=profile_id).exists():
# #                 user = Myprofile.objects.filter(profile_id=profile_id).first()
# #                 kids_id = request.data["kids_id"]
# #                 schoolkionly_id = request.data["schoolkionly_id"]
# #                 gradekionly_id = request.data['gradekionly_id']
# #                 full_name = request.data['full_name']
# #                 email = request.data['email']
# #                 password = request.data['password']
# #                 if kids_id:
# #                     lst = kids_id.split(",")
# #                     for i in lst:
# #                         rko = Kids_profile.objects.filter(kds_profile_id=i).first()
# #                         rko.profile_id_id= profile_id
# #                         rko.save()
# #                 if schoolkionly_id:
# #                     user.schoolkionly_id = schoolkionly_id
# #                 if gradekionly_id:
# #                     user.gradekionly_id =gradekionly_id
# #                 if full_name:
# #                     user.full_name = full_name
# #                 if email:
# #                     user.email = email
# #                 if password:
# #                     user.password = password
# #                 user.save()
# #                 serializer = MyprofilesSerializer(user)
# #                 return Response({"success":True, "message": "parents details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "parents details doesn't exist or invalid parents id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def deleteparent_details(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['profile_id'] == "":
# #                 return Response({"success":False, "message": "profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             profile_id = request.data['profile_id']
# #             if Myprofile.objects.filter(profile_id=profile_id).exists():
# #                 user = Myprofile.objects.filter(profile_id=profile_id).first()
# #                 user.delete()
# #                 return Response({"success":True, "message": "parents details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "parents details does'nt exist or invalid parents id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['GET'])
# # def allparents_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             gt = Myprofile.objects.all().order_by("-profile_id")
# #             serializer = parentsandkidsdataSerializer(gt, many=True)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Here is your parents listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def add_membership_plans(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             school_id = request.data['school_id']
# #             grades_id = request.data['grades_id']
# #             plan_name = request.data['plan_name']
# #             duration_id = request.data['duration_id']
# #             weeks_id = request.data['weeks_id'].split(",")
# #             plan_Benefits_features = request.data['plan_Benefits_features']
# #             desc = request.data['desc']
# #             recommended = request.data["recommended"]
# #             plan_price = request.data['plan_price']
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 ltt = Membership_plans.objects.create(school_id_id=school_id,grades_id_id=grades_id,plan_name=plan_name,duration_id_id=duration_id,plan_Benefits_features=plan_Benefits_features,desc=desc,recommended=recommended,plan_price=plan_price)
# #                 if not weeks_id=="":
# #                     plan_id = ltt.plan_id
# #                     for i in weeks_id:
# #                         rko = Plans_available.objects.create(plan_id_id=plan_id,weeks_id_id=i)
# #                         rko.save()
# #                     data = Membership_plans.objects.get(plan_id=ltt.plan_id)
# #                     serializer = PlansweeksavailableSerializer(data) 
# #                     return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #                 else:
# #                     # ltt = Membership_plans.objects.create(school_id_id=school_id,grades_id_id=grades_id,plan_name=plan_name,duration_id_id=duration_id,plan_Benefits_features=plan_Benefits_features,desc=desc,recommended=recommended,plan_price=plan_price)
# #                     # ltt.save()
# #                     serializer = MembershipplansSerializer(ltt)
# #                     return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)       
# #             else:
# #                 return Response({"message": "School not found","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND) 
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)



# # @api_view(['POST'])
# # def getmembership_planslisting(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['plan_id'] == "":
# #                 return Response({"success":False, "message": "plan_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             plan_id = request.data['plan_id']
# #             if Membership_plans.objects.filter(plan_id=plan_id).exists():
# #                 ltt = Membership_plans.objects.filter(plan_id=plan_id).first()
# #                 serializer = MembershipplansSerializer(ltt)
# #                 return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "plan does'nt exist or invalid membership id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #             return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def editmembership_plan(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['plan_id'] == "":
# #                 return Response({"success":False, "message": "plan_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             plan_id = request.data['plan_id']
# #             if Membership_plans.objects.filter(plan_id=plan_id).exists():
# #                 user = Membership_plans.objects.filter(plan_id=plan_id).first()
# #                 school_id = request.data['school_id']
# #                 grades_id = request.data['grades_id']
# #                 plan_name = request.data['plan_name']
# #                 duration_id = request.data['duration_id']
# #                 weeks_id = request.data['weeks_id'].split(",")
# #                 plan_Benefits_features = request.data['plan_Benefits_features']
# #                 desc = request.data['desc']
# #                 recommended = request.data['recommended']
# #                 plan_price = request.data['plan_price']
# #                 plan__id =  request.data["plan__id"]
# #                 if plan__id:
# #                     user.plan__id = plan__id
# #                 if school_id:
# #                     user.school_id_id= school_id
# #                 if grades_id:
# #                     user.grades_id_id= grades_id
# #                 if plan_name:
# #                     user.plan_name = plan_name
# #                 if duration_id:
# #                     user.duration_id_id= duration_id
# #                 if weeks_id:
# #                     plan_id = user.plan_id
# #                     datta = Plans_available.objects.filter(plan_id=plan_id)
# #                     datta.delete()
# #                     for i in weeks_id:
# #                         rko = Plans_available.objects.create(plan_id_id=plan_id,weeks_id_id=i)
# #                         rko.save()
# #                 if plan_Benefits_features:
# #                     user.plan_Benefits_features = plan_Benefits_features
# #                 if desc:
# #                     user.desc = desc
# #                 if recommended:
# #                     user.recommended = recommended
# #                 if plan_price:
# #                     user.plan_price = plan_price
# #                 user.save()
# #                 serializer = MembershipplansSerializer(user)
# #                 return Response({"success":True, "message": "plan details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "plan details does'nt exist or invalid plan id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def deletemembership_plan(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['plan_id'] == "":
# #                 return Response({"success":False, "message": "plan_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             plan_id = request.data['plan_id']
# #             if Membership_plans.objects.filter(plan_id=plan_id).exists():
# #                 user = Membership_plans.objects.filter(plan_id=plan_id).first()
# #                 user.delete()
# #                 return Response({"success":True, "message": "plan details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "plan details does'nt exist or invalid plan id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def allmembership_plan_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['school_id'] == "":
# #                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             school_id = request.data['school_id']
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 ltt = Schools_listing.objects.filter(school_id=school_id).first()
# #                 serializer = SchoolswithmembershiplistingSerializer(ltt)
# #                 return Response({"success":True, "message": "Here is your membership listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)



# # @api_view(["POST"])
# # def buy_plan(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             plan_id = request.data["plan_id"]
# #             profile_id = request.data["profile_id"]
# #             kds_profile_id = request.data["kds_profile_id"]
# #             if  Kids_profile.objects.filter(kds_profile_id=kds_profile_id,status=1).exists():
# #                 return Response({"message": "Kid already have active plan","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
# #             else:
# #                 schooldata = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
                
# #                 schoolalldata = schooldata.school_id.school_id
# #                 print(schoolalldata, "Sxh")
# #                 ss = schooldata.school_id  # ss will be a Schools_listing object
    
# #                 # Assuming that 'plan_id', 'profile_id', and 'kds_profile_id' have valid values
# #                 ltt = Selected_plans.objects.create(
# #                     plan_id_id=plan_id,
# #                     profile_id_id=profile_id,
# #                     kds_profile_id_id=kds_profile_id,
# #                     school_id=ss,  # Use ss directly as the school_id value
# #                     plan_status=1
# #                 )
# #                 ddt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
# #                 ddt.status = 1
# #                 ddt.save()
# #                 return Response({"success":True, "message": "Plan added successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def get_active_plan_list(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['profile_id'] == "":
# #                 return Response({"success":False, "message": "profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             profile_id = request.data['profile_id']
# #             ldtt = Selected_plans.objects.filter(profile_id=profile_id,plan_status=1)
# #             serializer = SelectedplanswithparentsSerializer(ldtt, many=True)
# #             return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
            

# # # @api_view(["POST"])
# # # def delete_buy_plan(request):
# # #     auth = authentication.get_authorization_header(request).split()
# # #     if auth:
# # #         aaa = str(auth[1].split())
# # #         sss = aaa.split("'")
# # #         token = sss[1]
# # #         try:
# # #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# # #         except:
# # #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# # #         member = Super.objects.filter(super_id=payload['super_id']).first()
# # #         if member:




# # @api_view(['GET'])
# # def allweekdays_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             gt = Weeks.objects.all().order_by("-weeks_id")
# #             serializer = WeeksSerializer(gt, many=True)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Here is your Weekdays listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['GET'])
# # def allgrade_duration_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'") 
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             gt = Grade_duration.objects.all().order_by("-duration_id")
# #             serializer = GradedurationSerializer(gt, many=True)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Here is your duration listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
 

# # @api_view(['POST'])
# # def addgrades_forschool(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             school_id = request.data["school_id"]
# #             name = request.data["name"].split(",")
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 for i in name:
# #                     llt = Grades.objects.create(school_id_id=school_id,name=i) 
# #                     llt.save()
# #                 return Response({"success":True, "message": "Grades added successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "School not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def editgrades_forschool(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['grades_id'] == "":
# #                 return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             grades_id = request.data['grades_id']
# #             user = Grades.objects.filter(grades_id=grades_id).first()
# #             if user:
# #                 school_id = request.data["school_id"]
# #                 name = request.data["name"]
# #                 if school_id:
# #                     user.school_id_id= school_id
# #                 if name:
# #                     user.name = name
# #                 user.save() 
# #                 return Response({"success":True, "message": "Grades updated successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({'message': "Grade not found"}, status=status.HTTP_400_BAD_REQUEST)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def deletegrade_forschool(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['grades_id'] == "":
# #                 return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             grades_id = request.data['grades_id']
# #             if Grades.objects.filter(grades_id=grades_id).exists():
# #                 user = Grades.objects.filter(grades_id=grades_id).first()
# #                 user.delete()
# #                 return Response({"success":True, "message": "grade details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def allgrades_listing_forschool(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             if request.data['school_id'] == "":
# #                 return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             school_id = request.data['school_id']
# #             if Schools_listing.objects.filter(school_id=school_id).exists():
# #                 school_name = Schools_listing.objects.filter(school_id=school_id).first()
# #                 if Grades.objects.filter(school_id=school_id).exists():
# #                     ldtt = Grades.objects.filter(school_id=school_id)
# #                     serializer = GradeswithschoolSerializer(ldtt,many=True)
# #                     x = serializer.data
# #                     dict = {"school_id":school_id,"school_name":ldtt.first().school_id.school_name}
# #                     return Response({"success":True, "message": "Here is your grade listing","data":x,"school_detail":dict,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #                 else:
# #                     dict = {"school_id":school_id,"school_name":school_name.school_name}
# #                     return Response({"message": "school not found","school_detail":dict,"status":status.HTTP_200_OK}, status=status.HTTP_200_OK)       
# #             else:
# #                 return Response({"message": "Grades not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #         else:
# #            return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def single_grade_info(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['grades_id'] == "":
# #                 return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             grades_id = request.data['grades_id']
# #             if Grades.objects.filter(grades_id=grades_id).exists():
# #                 user = Grades.objects.filter(grades_id=grades_id).first()
# #                 serializer = GradesSerializer(user)
# #                 return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def kidslisting_according_grades(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['grades_id'] == "":
# #                 return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             grades_id = request.data['grades_id']
# #             if Grades.objects.filter(grades_id=grades_id).exists():
# #                 user = Grades.objects.filter(grades_id=grades_id).first()
# #                 serializer = kidslistingwithgradesSerializer(user)
# #                 return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(["POST"])
# # def palns_according_to_grade(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['grades_id']=="":
# #                 return Response({"success":False, "message": "grades_id is required" }, status=status.HTTP_400_BAD_REQUEST)
# #             grades_id = request.data['grades_id']
# #             ltt = Grades.objects.filter(grades_id=grades_id).first()
# #             serializer = GradewithplansSerializer(ltt)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
# #         else:
# #             return Response({"success":False, "message": "parent not found"}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# # @api_view(["POST"])
# # def student_with_parents(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['kds_profile_id']=="":
# #                 return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST)
# #             kds_profile_id = request.data['kds_profile_id']
# #             ltt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
# #             serializer = StudentswithparentsSerializer(ltt)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
# #         else:
# #             return Response({"success":False, "message": "parent not found"}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required"},status=status.HTTP_400_BAD_REQUEST)


# # @api_view(["GET"])
# # def all_userdata(request):
# #     if Super.objects.all().exists:
# #         data = Super.objects.all()
# #         serializer = adddataSerializer(data,many=True)
# #         x = serializer.data
# #         return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
# #     else:
# #         return Response({"success":False, "message": "Data not found"}, status=status.HTTP_404_NOT_FOUND)


# # @api_view(['GET'])
# # def allpurchaseplans_listing(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if member:
# #             gt = Selected_plans.objects.all().order_by("-selected_plans_id")
# #             serializer = SelectedplansSerializer(gt, many=True)
# #             x = serializer.data
# #             return Response({"success":True, "message": "Here is your purchase plan listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #         else:
# #            return Response({"message": "List not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)


# # @api_view(['POST'])
# # def singlebuypaln_info(request):
# #     auth = authentication.get_authorization_header(request).split()
# #     if auth:
# #         aaa = str(auth[1].split())
# #         sss = aaa.split("'")
# #         token = sss[1]
# #         try:
# #             payload = jwt.decode(token, 'secret', algorithms=['HS256'])
# #         except:
# #             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
# #         member = Super.objects.filter(super_id=payload['super_id']).first()
# #         if (member):
# #             if request.data['selected_plans_id'] == "":
# #                 return Response({"success":False, "message": "selected_plans_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
# #             selected_plans_id = request.data['selected_plans_id']
# #             if Selected_plans.objects.filter(selected_plans_id=selected_plans_id).exists():
# #                 user = Selected_plans.objects.filter(selected_plans_id=selected_plans_id).first()
# #                 serializer = SelectedplansSerializer(user)
# #                 return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
# #             else:
# #                 return Response({"message": "plan details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
# #         else:
# #           return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# #     else:
# #         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
