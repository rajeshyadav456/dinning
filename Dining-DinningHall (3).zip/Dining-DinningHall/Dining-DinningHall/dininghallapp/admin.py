from django.contrib import admin
from .models import *
# Register your models here.

admin.register(Myprofile,Kids_profile,Email_otp,Super,Schools_listing,Membership_plans,Plans_available,Selected_plans,Token_data,Grades,Weeks,Grade_duration,Membership_plan)(admin.ModelAdmin)