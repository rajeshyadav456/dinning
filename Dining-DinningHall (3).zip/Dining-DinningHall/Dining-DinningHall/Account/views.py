from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework import viewsets,generics, status
from django.contrib.auth import get_user_model
from rest_framework.response import Response
from django.contrib.auth.hashers import check_password, make_password
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
# from dininghallapp.models import *
# from dininghallapp.serializers import *
from django.db import IntegrityError  # Import IntegrityError

from django.shortcuts import render,redirect
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.db.models import Q
from django.contrib.auth import logout
import math
from rest_framework import status
from django.contrib import messages
from django.contrib.auth import authenticate,login as login_me,logout as logout_me
from rest_framework.views import APIView
from rest_framework.response import Response
import requests
from .serializers import *
from datetime import date, datetime, timedelta
import jwt
import random
from django.conf import settings
from django.core.mail import send_mail
from .models import *
from django.views.decorators.csrf import csrf_exempt
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from rest_framework import authentication
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import generics

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.decorators import api_view, permission_classes

from django.contrib.auth import get_user_model
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from django.contrib.auth.hashers import check_password
from django.db.models import Count

# # Create your views here.

@api_view(["POST"])
def create_user(request):
    username = request.data['username']
    password = request.data['password']
    ftt = User.objects.create(username=username,password=password)
    ftt.save()
    serializer = MyprofilesSerializer(ftt)
    return Response({"success":True, "message": "Sign up Successfully","data":serializer.data}, status=status.HTTP_200_OK)


class LoginApi(APIView):
    serializer_class = LoginDataSerializer

    def post(self, request):
        serializer = LoginDataSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        username = data['username']
        password = data['password']

        try:
            user = get_user_model().objects.get(username=username)
        except get_user_model().DoesNotExist:
            return Response({
                "success": False, 
                "message": "User with this username does not exist.",
            }, status=status.HTTP_404_NOT_FOUND)

        validate = check_password(password, user.password)

        if validate:
            if user.is_superuser:
                user.last_login = timezone.now()
                user.save()
                token = str(RefreshToken.for_user(user))
                access = str(RefreshToken.for_user(user).access_token)
                return Response({
                    "success": True, 
                    "message": "Logged In Successfully",
                    "user": UsersSerializer(user, context={'request': request}).data,
                    "access": access,
                    "refresh": token,
                })
            else:
                return Response({
                    "success": False,
                    "message": "You are not authorized to log in as a non-superuser.",
                }, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({
                "success": False,
                "message": "Invalid credentials. Please check your username and password.",
            }, status=status.HTTP_401_UNAUTHORIZED)
class getprofile(APIView):
    def get(self,request,*args,**kwargs):
        user_id = request.user.id 
        data=User.objects.filter(id=user_id).values('username','profile_pic','full_name','address','email','country_code','phone_number')
        if data:
            return Response({'sucess':True,'message':'Here id your Profile',"data":data,'status':status.HTTP_200_OK},status=status.HTTP_200_OK)
        else:
            return Response({'success':False,'message':'Not Found Profile Id','status':status.HTTP_400_BAD_REQUEST},status=status.HTTP_400_BAD_REQUEST)    
 
@api_view(['PUT'])
def adminedit_profile(request):
    user_id=request.user.id
    address = request.POST.get('address')
    full_name = request.POST.get('full_name')
    email = request.POST.get('email')
    country_code = request.POST.get('country_code')
    phone_number = request.POST.get('phone_number')

    try:
        # Retrieve the Super instance by super_id
        super_instance = User.objects.filter(id=user_id).first()
        profile_pic = request.FILES.get('profile_pic')
        if profile_pic:
            super_instance.profile_pic = profile_pic

        super_instance.profile_pic = profile_pic
        super_instance.address=address
        super_instance.full_name = full_name
        super_instance.email = email
        super_instance.country_code = country_code
        super_instance.phone_number = phone_number
        super_instance.save()

        return Response({'success': True, 'message': 'Profile updated successfully','status':status.HTTP_200_OK},status=status.HTTP_200_OK)
    except Super.DoesNotExist:
        raise Http404("Super instance does not exist")
    


# @api_view(["GET"])
# def dashboard_admin(request):
#     auth = authentication.get_authorization_header(request).split()
#     if auth:
#         aaa = str(auth[1].split())
#         sss = aaa.split("'")
#         token = sss[1]
#         try:
#             payload = jwt.decode(token, 'secret', algorithm=['HS256'])
#         except:
#             return Response({"success":False, "message": "Token is expired or invalid","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
#         member = Super.objects.filter(super_id=payload['super_id']).first()
#         if (member):
#             user = Super.objects.get(super_id=payload['super_id'])
#             total_schools = Schools_listing.objects.all().count()
#             total_parents = Myprofile.objects.all().count()
#             total_students = Kids_profile.objects.all().count()
#             total_plans = Membership_plans.objects.all().count()
#             total_purchase = Selected_plans.objects.all().count()
#             return Response({"success":True, "message": "Here is your dashboard details","total_schools":total_schools,"total_parents":total_parents,"total_students":total_students,"total_plans":total_plans,"total_purchase":total_purchase,"status":status.HTTP_200_OK}, status=status.HTTP_200_OK)
#         else:
#             return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "Token is required","status":status.HTTP_401_UNAUTHORIZED},status=status.HTTP_401_UNAUTHORIZED)
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def dashboard_admin(request):
    total_schools = Schools_listing.objects.all().count()
    total_parents = User.objects.all().count()
    total_students = Kids_profile.objects.all().count()
    total_plans= Membership_plan.objects.all().count()
    total_purchase = Selected_plans.objects.all().count()
    return Response({"success":True, "message": "Here is your dashboard details","total_schools":total_schools,"total_parents":total_parents,"total_students":total_students,"total_plans":total_plans,"total_purchase":total_purchase,"status":status.HTTP_200_OK}, status=status.HTTP_200_OK)
    
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def add_school_listing(request):
    try:
        school_name = request.data["school_name"]
        image = request.data['image']
        email = request.data['email']
        country_code = request.data['country_code']
        contact_number = request.data['contact_number']
        select_country = request.data['select_country']
        select_state  = request.data['select_state']
        select_city = request.data['select_city']
        postal_code = request.data['postal_code']
        street_number = request.data['street_number']
        apartment_number = request.data['apartment_number']
        # username_Code=request.data['username_Code']
        dtt = slice(5)
        usern = school_name[dtt]
        ame = random.randint(10000,99999)
        ldt = str(ame)
        username = usern+ldt
        ltt = Schools_listing.objects.create(school_name=school_name,image=image,email=email,country_code=country_code,contact_number=contact_number,select_country=select_country,select_state=select_state,select_city=select_city,postal_code=postal_code,street_number=street_number,apartment_number=apartment_number,username_Code=username)
        ltt.save()
        data = Schools_listing.objects.get(school_id=ltt.school_id)
        serializer = SchoolslistingSerializer(data)
        return Response({"success":True, "message": "school details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    except:
        return Response({"success":True, "message": "school details not added successfully","status":status.HTTP_400_BAD_REQUEST},status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST'])
# def getschool_details(request):
#     if request.data['school_id'] == "":
#         return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
#     school_id = request.data['school_id']
#     if Schools_listing.objects.filter(school_id=school_id).exists():
#         ltt = Schools_listing.objects.filter(school_id=school_id).first()
#         serializer = SchoolslistingSerializer(ltt)
#     return Response({"success":True, "message": "Here is your school details","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
           

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Count

class getschool_details(APIView):
    def post(self, request, *args, **kwargs):
        school_id = request.POST.get('school_id')
        data = Schools_listing.objects.filter(school_id=school_id).values()
        data1 = Schools_listing.objects.values('school_name').annotate(total_students=Count('school_id'))

        # Find the total_students for the specific school
        total_students_for_school = None
        for school_data in data1:
            if school_data['school_name'] == data[0]['school_name']:  # Assuming 'school_name' is unique
                total_students_for_school = school_data['total_students']
                break

        # Add the 'total_student' field to the specific school's data
        if data and total_students_for_school is not None:
            data[0]['total_student'] = total_students_for_school
            return Response({"success": True, "message": "Here is your school details", "data": data, "status": status.HTTP_200_OK}, status=status.HTTP_200_OK)
        else:
            return Response({"success": False, "message": "School not found", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def update_school_detail(request):
        # if not request.POST.get('school_id') == "":
        #     return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
        school_id = request.POST.get('school_id')
        if Schools_listing.objects.filter(school_id=school_id).exists():
            user = Schools_listing.objects.filter(school_id=school_id).first()
            school_name = request.data["school_name"]
            image = request.data['image']
            email = request.data['email']
            country_code = request.data['country_code']
            contact_number = request.data['contact_number']
            select_country = request.data['select_country']
            select_state  = request.data['select_state']
            select_city = request.data['select_city']
            postal_code = request.data['postal_code']
            street_number = request.data['street_number']
            apartment_number = request.data['apartment_number']
            if school_name:
                user.school_name = school_name
            if image:
                if "/" in image:
                    image = image
                else:
                    user.image = image
            if email:
                user.email = email
            if country_code:
                user.country_code = country_code
            if contact_number:
                user.contact_number = contact_number
            if select_country:
                user.select_country = select_country
            if select_state:
                user.select_state = select_state
            if select_city:
                user.select_city = select_city
            if postal_code:
                user.postal_code = postal_code
            if street_number:
                user.street_number = street_number
            if apartment_number:
                user.apartment_number = apartment_number
                user.save()
                serializer = SchoolslistingSerializer(user)
                return Response({"success":True, "message": "school details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "school id not found","status":status.HTTP_400_BAD_REQUEST},status=status.HTTP_400_BAD_REQUEST)



@api_view(["POST"])
@permission_classes([IsAuthenticated])
def deleteschool(request):
    school_id = request.data['school_id']
    if Schools_listing.objects.filter(school_id=school_id).exists():
        user = Schools_listing.objects.filter(school_id=school_id).first()
        user.delete()
        return Response({"success":True, "message": "school details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
       


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def school_listing(request):
    gt = Schools_listing.objects.all().order_by('-school_id').values()
    lst =[]
    for i in gt:
        idd = (i['school_id'])
        rrr = Kids_profile.objects.filter(school_id=idd).count()
        serializer = SchoolslistingSerializer(i)
        x = serializer.data
        x.update({"student_count":rrr})
        lst.append(x)
    
    return Response({"success":True, "message": "Here is your school details","data":lst,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)


# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def adminadd_kids(request):
#     school_id = request.data['school_id']
#     kid_profile_pic = request.data['kid_profile_pic']
#     kid_full_name = request.data['kid_full_name']
#     roll_no = request.data["roll_no"]
#     dob = request.data['dob']
#     grades_id = request.data['grades_id']
#         # grades_id = request.data.getlist('grades_id')
#     dtt = slice(6)
#     usern = kid_full_name[dtt]
#     ldt = str(roll_no)
#     username = usern+ldt
#     kkk = Kids_profile.objects.create(school_id_id=school_id,kid_profile_pic=kid_profile_pic,kid_full_name=kid_full_name,roll_no=roll_no,dob=dob,grades_id_id=grades_id,username_Code=username)
#     serializer = KidsprofileSerializer(kkk)
#     return Response({"success":True, "message": "kids details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
  
# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def adminadd_kids(request):
#     # Check if 'school_id' is provided in the request data
#     # if 'school_id' not in request.data:
#     #     return Response({"success": False, "message": "school_id is required", "status": status.HTTP_400_BAD_REQUEST})
#     if request.POST.get('school_id') == "":
#             return Response({"success":False, "message": "School Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     school_id = request.POST.get('school_id')
#     if Schools_listing.objects.filter(school_id=school_id).first() == None:
#             return Response({"success":False, "message": "Please Enter Valid School Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     # Check if 'grades_id' is provided in the request data
#     if request.POST.get('grades_id') == "":
#             return Response({"success":False, "message": "Grades Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     grades_id = request.POST.get('grades_id')
#     if Grades.objects.filter(grades_id=grades_id).first() == None:
#             return Response({"success":False, "message": "Please Enter Valid Grades Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     school_id = request.data['school_id']
#     kid_profile_pic = request.data['kid_profile_pic']
#     kid_full_name = request.data['kid_full_name']
#     roll_no = request.data["roll_no"]
#     dob = request.data['dob']
#     grades_id = request.data['grades_id']
#     dtt = slice(6)
#     usern = kid_full_name[dtt]
#     ldt = str(roll_no)
#     username = usern + ldt

#     kkk = Kids_profile.objects.create(
#         school_id_id=school_id,
#         kid_profile_pic=kid_profile_pic,
#         kid_full_name=kid_full_name,
#         roll_no=roll_no,
#         dob=dob,
#         grades_id_id=grades_id,
#         username_Code=username
#     )
    
#     serializer = KidsprofileSerializer(kkk)
    
#     return Response(
#         {"success": True, "message": "kids details added successfully", "data": serializer.data, "status": status.HTTP_200_OK},
#         status=status.HTTP_200_OK
#     )
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def adminadd_kids(request):
    # Check if 'school_id' is provided in the request data
    if request.POST.get('school_id') == "":
        return Response({"success": False, "message": "School Id is required" }) 
    
    school_id = request.POST.get('school_id')
    
    if Schools_listing.objects.filter(school_id=school_id).first() is None:
        return Response({"success": False, "message": "Please Enter Valid School Id" })

    # Check if 'grades_id' is provided in the request data
    if request.POST.get('grades_id') == "":
        return Response({"success": False, "message": "Grades Id is required" }) 
    
    grades_id = request.POST.get('grades_id')
    
    if Grades.objects.filter(grades_id=grades_id).first() is None:
        return Response({"success": False, "message": "Please Enter Valid Grades Id" },)

    # Check if 'grades_id' is associated with the provided 'school_id'
    if Grades.objects.filter(grades_id=grades_id, school_id=school_id).first() is None:
        return Response({"success": False, "message": "Grades Id is not associated with the provided School Id" })

    # The rest of your code to create the kid profile and respond with success

    school_id = request.data['school_id']
    kid_profile_pic = request.data['kid_profile_pic']
    kid_full_name = request.data['kid_full_name']
    roll_no = request.data["roll_no"]
    dob = request.data['dob']
    grades_id = request.data['grades_id']
    dtt = slice(6)
    usern = kid_full_name[dtt]
    ldt = str(roll_no)
    username = usern + ldt

    kkk = Kids_profile.objects.create(
        school_id_id=school_id,
        kid_profile_pic=kid_profile_pic,
        kid_full_name=kid_full_name,
        roll_no=roll_no,
        dob=dob,
        grades_id_id=grades_id,
        username_Code=username
    )
    
    serializer = KidsprofileSerializer(kkk)
    
    return Response(
        {"success": True, "message": "Kids details added successfully", "data": serializer.data, "status": status.HTTP_200_OK}
    )

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def getkids_details(request):
    if request.data['kds_profile_id'] == "":
        return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    kds_profile_id = request.data['kds_profile_id']
    if Kids_profile.objects.filter(kds_profile_id=kds_profile_id).exists():
        ltt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
        serializer = KidsprofileSerializer(ltt)       
        return Response({"success":True, "message": "kid details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "kid profile does'nt exist or invalid kid id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
     
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def kidsupdate_details(request):
    if request.data['kds_profile_id'] == "":
        return Response({"success":False, "message": "kds_profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    kds_profile_id = request.data['kds_profile_id']
    if Kids_profile.objects.filter(kds_profile_id=kds_profile_id).exists():
        user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
        school_id = request.data["school_id"]
        grades_id = request.data['grades_id']
        kid_profile_pic = request.data['kid_profile_pic']
        kid_full_name = request.data["kid_full_name"]
        roll_no = request.data["roll_no"]
        dob = request.data['dob']
        if school_id:
            user.school_id_id= school_id
        # if 'grades_id' in request.data:
        #     grades_ids = request.data['grades_id']
        #     user.grades_id.set(grades_ids)  # Update grades using the set method
        if grades_id:
            user.grades_id_id = grades_id
        if kid_profile_pic:
            if "/" in kid_profile_pic:
                kid_profile_pic = kid_profile_pic
            else:
                user.kid_profile_pic = kid_profile_pic
        if kid_full_name:
            user.kid_full_name = kid_full_name
        if roll_no:
            user.roll_no = roll_no
        if dob:
            user.dob = dob
            user.save()
            serializer = KidsprofileSerializer(user)
            return Response({"success":True, "message": "kid details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
        else:
            return Response({"message": "kid details does'nt exist or invalid kid id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
       

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def delete_kids_details(request):
    if request.data['kds_profile_id'] == "":
            return Response({"success":False, "message": "kds_profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    kds_profile_id = request.data['kds_profile_id']
    if Kids_profile.objects.filter(kds_profile_id=kds_profile_id).exists():
        user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
        user.delete()
        return Response({"success":True, "message": "kid details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "kid details does'nt exist or invalid kid id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
       
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def adminside_kids_listing(request):
    gt = Kids_profile.objects.all().order_by("-kds_profile_id")
    serializer = KidsprofileSerializer(gt , many=True)
    x = serializer.data
    return Response({"success":True, "message": "Here is your kids listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK) 

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def student_with_parents(request):
    if request.data['kds_profile_id']=="":
        return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    kds_profile_id = request.data['kds_profile_id']
    try:
        ltt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
    except Kids_profile.DoesNotExists():
        ltt = None
        return Response({"success":False, "message": "Kids Not Found"}, status=status.HTTP_400_BAD_REQUEST)
    if ltt is not None:
        lpid = ltt.profile_id_id
    else:
        return Response({"success":False, "message": "Kids Not Found"}, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        sst = User.objects.filter(id = lpid).first()
    except Myprofile.DoesNotExist:
        sst = None
        return Response({"success":False, "message": "Parent Not Found"}, status=status.HTTP_400_BAD_REQUEST)
    
    if  sst == None:
        return Response({"success":False, "message": "Parent Not Found"}, status=status.HTTP_400_BAD_REQUEST)
    else:
        if sst.full_name == None or sst.full_name == "":
            return Response({"success":False, "message": "Parent Not Found"}, status=status.HTTP_400_BAD_REQUEST)
    serializer = StudentswithparentsSerializer(ltt)
    x = serializer.data
    return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
    

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def addparent_admin(request):
    kids_id = request.data["kids_id"]
    schoolkionly_id = request.data["schoolkionly_id"]
    gradekionly_id = request.data['gradekionly_id']
    full_name = request.data['full_name']
    email = request.data['email']
    password = request.data['password']
    username = request.data['username']
    if (User.objects.filter(username=username).exists()):
        return Response({'success':False , 'message':"Username Already Exists ! it must be Unique"} , status=status.HTTP_400_BAD_REQUEST)
    dtt = slice(4)
    usern = full_name[dtt]
    ame = random.randint(10000,99999)
    ldt = str(ame)
    username_Code = usern+ldt
    ltt = User.objects.create(schoolkionly_id=schoolkionly_id,gradekionly_id=gradekionly_id,full_name=full_name,email=email,username_Code=username_Code ,username=username )
    ltt.set_password(password)
    ltt.save()
    id = ltt.id
    lst = kids_id.split(",")
    for i in lst:
        rko = Kids_profile.objects.filter(kds_profile_id=i).first()
        rko.profile_id_id = id
        rko.save()
    data = User.objects.get(id=ltt.id)
    serializer = MyprofilesSerializer(data)
    return Response({"success":True, "message": "parents details added successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def getparent_details(request):
    profile_id = request.POST.get('profile_id')
    # profile_id=request.user.id

    try:
        parent_profile = User.objects.get(id=profile_id)
    except User.DoesNotExist:
        return Response({"success": False, "message": "Parent profile does not exist or invalid parent ID", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

    parent_serializer = parentsandkidsdataSerializer(parent_profile)
    parent_data = parent_serializer.data

    kids_profiles = Kids_profile.objects.filter(profile_id=parent_profile)

    if kids_profiles.exists():
        kids_serializer = KidsprofileSerializer(kids_profiles, many=True)
        kids_data = kids_serializer.data

        # Remove the 'profile_id' field from each kid's details
        for kid in kids_data:
            kid.pop("profile_id")

        parent_data["kids_details"] = kids_data

        return Response({"success": True, "message": "Parent and kids details retrieved successfully", "data": parent_data, "status": status.HTTP_200_OK}, status=status.HTTP_200_OK)
    else:
        return Response({"success": False, "message": "No Kids Added", "data": parent_data, "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def editparent_profile(request):
    if request.data['profile_id'] == "":
        return Response({"success":False, "message": "kds_profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    profile_id = request.data['profile_id']
    # user_id=request.user.id
    if User.objects.filter(id=profile_id).exists():
        user = User.objects.filter(id=user_id).first()
        kids_id = request.data["kids_id"]
        schoolkionly_id = request.data["schoolkionly_id"]
        gradekionly_id = request.data['gradekionly_id']
        full_name = request.data['full_name']
        email = request.data['email']
        password = request.data['password']
        if kids_id:
            kds_ids = kids_id.split(",")
            # check Kids_profile who has Myprofile parenet 
            kk = Kids_profile.objects.filter(profile_id = user)
            for j in kk:
                # ( remove myparent )
                j.profile_id = None
                j.save()
            for k_id in kds_ids:
                hh = Kids_profile.objects.filter(kds_profile_id = k_id )
                for kid_profile in hh:
                    # (add myparent )
                    kid_profile.profile_id = user
                    kid_profile.save()
        if schoolkionly_id:
            user.schoolkionly_id = schoolkionly_id
        if gradekionly_id:
            user.gradekionly_id =gradekionly_id
        if full_name:
            user.full_name = full_name
        if email:
            user.email = email
        if password:
            user.password = password
            user.save()
            # ks = Kid
            serializer = MyprofilesSerializer(user)
            return Response({"success":True, "message": "parents details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
        else:
            return Response({"message": "parents details doesn't exist or invalid parents id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
    else:
        return Response({"message": "parents details doesn't exist or invalid parents id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def deleteparent_details(request):
    profile_id = request.data.get('profile_id', '')

    try:
        user = User.objects.get(id=profile_id)
        
        # Check if the user is a superuser and prevent deletion
        if user.is_superuser:
            return Response({"success": False, "message": "Cannot delete a superuser.", "status": status.HTTP_403_FORBIDDEN}, status=status.HTTP_403_FORBIDDEN)
        
        user.delete()
        return Response({"success": True, "message": "Parent's details deleted successfully", "status": status.HTTP_200_OK}, status=status.HTTP_200_OK)
    except User.DoesNotExist:
        return Response({"message": "Parent's details do not exist or invalid parent's ID", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def allparents_listing(request):
    gt = User.objects.all().order_by("-id").exclude(is_superuser=True)
    serializer = parentsandkidsdataSerializer(gt, many=True)
    x = serializer.data
    return Response({"success":True, "message": "Here is your parents listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
   

# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def add_membership_plans(request):
#     school_id = request.data['school_id']
#     grades_id = request.data['grades_id']
#     plan_name = request.data['plan_name']
#     duration_id = request.data['duration_id']
#     weeks_id = request.data['weeks_id'].split(",")
#     plan_Benefits_features = request.data['plan_Benefits_features']
#     desc = request.data['desc']
#     recommended = request.data["recommended"]
#     plan_price = request.data['plan_price']
#     if Schools_listing.objects.filter(school_id=school_id).exists():
#         ltt = Membership_plans.objects.create(school_id_id=school_id,grades_id_id=grades_id,plan_name=plan_name,duration_id_id=duration_id,plan_Benefits_features=plan_Benefits_features,desc=desc,recommended=recommended,plan_price=plan_price)
#         if not weeks_id=="":
#             plan_id = ltt.plan_id
#             for i in weeks_id:
#                 rko = Plans_available.objects.create(plan_id_id=plan_id,weeks_id_id=i)
#                 rko.save()
#                 data = Membership_plans.objects.get(plan_id=ltt.plan_id)
#                 serializer = PlansweeksavailableSerializer(data) 
#                 return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#         else:
#                     # ltt = Membership_plans.objects.create(school_id_id=school_id,grades_id_id=grades_id,plan_name=plan_name,duration_id_id=duration_id,plan_Benefits_features=plan_Benefits_features,desc=desc,recommended=recommended,plan_price=plan_price)
#                     # ltt.save()
#             serializer = MembershipplansSerializer(ltt)
#             return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)       
#     else:
#         return Response({"message": "School not found","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND) 
       
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_membership_plans(request):
    # Retrieve data from the request
    school_id = request.data.get('school_id')
    grades_id = request.data.get('grades_id')
    plan_name = request.data.get('plan_name')
    duration_id = request.data.get('duration_id')
    weeks_id = request.data.get('weeks_id', [])  # Default to an empty list if not provided
    plan_Benefits_features = request.data.get('plan_Benefits_features')
    desc = request.data.get('desc')
    recommended = request.data.get("recommended")
    plan_price = request.data.get('plan_price')
    
    print(type(duration_id))

    # Check if the school exists
    if Schools_listing.objects.filter(school_id=school_id).exists():
    # Create the membership plan
        ltt = Membership_plan.objects.create(
            school_id_id=school_id,
            grades_id_id=grades_id,
            plan_name=plan_name,
            duration_id_id=duration_id,
            plan_Benefits_features=plan_Benefits_features,
            desc=desc,
            recommended=recommended,
            plan_price=plan_price
        )
    
        if duration_id == "1":
            # Check if there are weeks_id provided
            if weeks_id:
                plan_id = ltt.plan_id
                if isinstance(weeks_id,str):
                    W_ID = weeks_id.split(",")
                elif isinstance(weeks_id, list):
                    W_ID = weeks_id
                else:
                    W_ID = None
                
                if W_ID is not None:
                    for week_id in W_ID:
                        # Create Plans_available objects for each week ID
                        Plans_available.objects.create(plan_id_id=plan_id, weeks_id_id=week_id)

                # Retrieve the created plan with associated weeks
                data = Membership_plan.objects.get(plan_id=ltt.plan_id)
                serializer = MembershipplansSerializer(data)

                return Response({
                    "success": True,
                    "message": "Here is your plan listing",
                    "data": serializer.data,
                }, status=status.HTTP_200_OK)
            else:
                return Response({"message" :"Week id not found"} ,status=status.HTTP_200_OK)
        elif duration_id == "2":
            # Retrieve the created plan with associated weeks
                data = Membership_plan.objects.get(plan_id=ltt.plan_id)
                serializer = Membershipplanserilizer(data)
                return Response({
                    "success": True,
                    "message": "Here is your plan listing",
                    "data": serializer.data,
                }, status=status.HTTP_200_OK)
        else:
             return Response({
                    "success": False,
                    "message": "No Validation Found",
                }, status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response({
            "message": "School not found",
        }, status=status.HTTP_404_NOT_FOUND)
    

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def getmembership_planslisting(request):
    if request.data['plan_id'] == "":
        return Response({"success": False, "message": "plan_id is required", "status": status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    plan_id = request.data['plan_id']

    if Membership_plan.objects.filter(plan_id=plan_id).exists():
        ltt = Membership_plan.objects.get(plan_id=plan_id)

        # Extract the lists of grade_id and duration_id from the request data
        grade_id_list = request.data.getlist('grade_id')
        duration_id_list = request.data.getlist('duration_id')

        # Update the user object with the new values
        
        if grade_id_list:
            ltt.grades_id= Grades.objects.get(grades_id=grade_id_list[0])
        if duration_id_list:
            ltt.duration_id=Grade_duration.objects.get(duration_id = duration_id_list[0])

        # Save the user object
        ltt.save()

        # Serialize the updated user data
        serializer = MembershipplansSerializer(ltt)

        # Return a response with a success message
        response_data = {
            "success": True,
            "message": "Plan details updated successfully",
            "data":serializer.data,
            "status": status.HTTP_200_OK
        }
        return Response(response_data, status=status.HTTP_200_OK)
    else:
        return Response({"message": "Plan does not exist or invalid membership id", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
# @api_view(["POST"])
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def editmembership_plan(request):
    if request.data.get('plan_id') == "":
        return Response({"success": False, "message": "plan_id is required", "status": status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
    
    plan_id = request.data['plan_id']
    
    if Membership_plan.objects.filter(plan_id=plan_id).exists():
        user = Membership_plan.objects.filter(plan_id=plan_id).first()
        
        school_id = request.data.get('school_id', user.school_id_id)
        grades_id = request.data.get('grades_id', user.grades_id_id)
        plan_name = request.data.get('plan_name', user.plan_name)
        duration_id = request.data.get('duration_id', user.duration_id_id)
        weeks_id = request.data.get('weeks_id', []) 
        plan_Benefits_features = request.data.get('plan_Benefits_features', user.plan_Benefits_features)
        desc = request.data.get('desc', user.desc)
        recommended = request.data.get('recommended', user.recommended)
        plan_price = request.data.get('plan_price', user.plan_price)
        plan__id = request.data.get('plan__id', user.plan_id)
        
        if plan__id:
            user.plan_id = plan__id
        
        if school_id:
            user.school_id_id = school_id
        
        if grades_id:
            user.grades_id_id = grades_id
        
        if plan_name:
            user.plan_name = plan_name
        
        if duration_id:
            if duration_id == "1":
                if weeks_id:
                    plan_id = user.plan_id
                    datta = Plans_available.objects.filter(plan_id=plan_id)
                    datta.delete()
                    
                    if isinstance(weeks_id,str):
                        W_ID = weeks_id.split(",")
                    elif isinstance(weeks_id, list):
                        W_ID = weeks_id
                    else:
                        W_ID = None
                        
                    if W_ID is not None:
                        for i in W_ID:
                            rko = Plans_available.objects.create(plan_id_id=plan_id, weeks_id_id=i)
                            rko.save()
                user.duration_id_id = duration_id
            elif duration_id == "2":
                user.duration_id_id = duration_id
                plan_id = user.plan_id
                datta = Plans_available.objects.filter(plan_id=plan_id)
                datta.delete()
            else:
                user.duration_id_id = user.duration_id_id
        
        if plan_Benefits_features:
            user.plan_Benefits_features = plan_Benefits_features
        
        if desc:
            user.desc = desc
        
        if recommended:
            user.recommended = recommended
        
        if plan_price:
            user.plan_price = plan_price
        
        user.save()
        serializer = MembershipplansSerializer(user)
        return Response({"success": True, "message": "plan details updated successfully", "data": serializer.data, "status": status.HTTP_200_OK}, status=status.HTTP_200_OK)
    else:
        return Response({"message": "plan details do not exist or invalid plan id", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

# @api_view(["POST"])
# @permission_classes([IsAuthenticated])
# def editmembership_plan(request):
#     if request.data['plan_id'] == "":
#         return Response({"success": False, "message": "plan_id is required", "status": status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

#     plan_id = request.data['plan_id']

#     if Membership_plans.objects.filter(plan_id=plan_id).exists():
#         user =    .objects.get(plan_id=plan_id)

#         # Extract the lists of grades_id, school_id, and duration_id from the request data
#         grades_id_list = request.data.get('grades_id', [])
#         school_id_list = request.data.get('school_id', [])
#         duration_id_list = request.data.get('duration_id', [])

#         # Update the user object with the new values
#         if not isinstance(grades_id_list, list):
#             grades_id_list = [grades_id_list]
#         if not isinstance(school_id_list, list):
#             school_id_list = [school_id_list]
#         if not isinstance(duration_id_list, list):
#             duration_id_list = [duration_id_list]


#         # Update other fields as before
#         user.plan_name = request.data.get('plan_name', user.plan_name)
#         user.plan_Benefits_features = request.data.get('plan_Benefits_features', user.plan_Benefits_features)
#         user.desc = request.data.get('desc', user.desc)
#         user.recommended = request.data.get('recommended', user.recommended)
#         plan_price = request.data.get('plan_price')

#         # Save the user object
#         user.save()

#         # Serialize the updated user data
#         serializer = MembershipplansSerializer(user)

#         # Return a response with the updated user data
#         response_data = {
#             "success": True,
#             "message": "plan details updated successfully",
#             "data": serializer.data,
#             "grades_id": grades_id_list,
#             "school_id": school_id_list,
#             "duration_id": duration_id_list,
#             "status": status.HTTP_200_OK
#         }
#         return Response(response_data, status=status.HTTP_200_OK)
#     else:
#         return Response({"message": "plan details do not exist or invalid plan id", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def deletemembership_plan(request):
    if request.data['plan_id'] == "":
        return Response({"success":False, "message": "plan_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    plan_id = request.data['plan_id']
    if Membership_plan.objects.filter(plan_id=plan_id).exists():
        user = Membership_plan.objects.filter(plan_id=plan_id).first()
        user.delete()
        return Response({"success":True, "message": "plan details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "plan details does'nt exist or invalid plan id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
    

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def allmembership_plan_listing(request):
    if request.data['school_id'] == "":
        return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    school_id = request.data['school_id']
    if Schools_listing.objects.filter(school_id=school_id).exists():
        ltt = Schools_listing.objects.filter(school_id=school_id).first()
        serializer = SchoolswithmembershiplistingSerializer(ltt)
        return Response({"success":True, "message": "Here is your membership listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
      

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def buy_plan(request):
    plan_id = request.data["plan_id"]
    profile_id = request.data["profile_id"]
    kds_profile_id = request.data["kds_profile_id"]
    if  Kids_profile.objects.filter(kds_profile_id=kds_profile_id,status=1).exists():
        return Response({"message": "Kid already have active plan","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
    else:
        try:
            p_id = Membership_plan.objects.filter(plan_id=plan_id).first()
        except Membership_plan.DoesNotExists:
            p_id = None
            
        try:
            pr_id = User.objects.filter(id = profile_id).first()
        except User.DoesNotExists:
            pr_id = None
        
        if p_id is not None:
            if pr_id is not None:
                schooldata = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
                schoolalldata = schooldata.school_id
                ssid = Schools_listing.objects.filter(school_id = schoolalldata.school_id).first()
                s_id = ssid.school_id
                ltt = Selected_plans.objects.create(plan_id_id=plan_id,profile_id_id=profile_id,kds_profile_id_id=kds_profile_id,school_id_id=s_id,plan_status=1)
                ddt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
                ddt.status = 1
                ddt.save()
                return Response({"success":True, "message": "Plan added successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
            else:
                return Response({"message": "Profile Id not matching","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({"message": "membership plan not matching","status":status.HTTP_401_UNAUTHORIZED}, status=status.HTTP_401_UNAUTHORIZED)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def get_active_plan_list(request):
    if request.data['profile_id'] == "":
        return Response({"success":False, "message": "profile_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
        profile_id = request.data['profile_id']
        ldtt = Selected_plans.objects.filter(profile_id=profile_id,plan_status=1)
        serializer = SelectedplanswithparentsSerializer(ldtt, many=True)
        return Response({"success":True, "message": "Here is your plan listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "User not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
        




@api_view(['GET'])
@permission_classes([IsAuthenticated])
def allweekdays_listing(request):
    gt = Weeks.objects.all().order_by("-weeks_id")
    serializer = WeeksSerializer(gt, many=True)
    x = serializer.data
    return Response({"success":True, "message": "Here is your Weekdays listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
   
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def allgrade_duration_listing(request):
    gt = Grade_duration.objects.all().order_by("-duration_id")
    serializer = GradedurationSerializer(gt, many=True)
    x = serializer.data
    return Response({"success":True, "message": "Here is your duration listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    
# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def addgrades_forschool(request):
#     school_id = request.data["school_id"]
#     name = request.data["name"].split(",")
#     if Schools_listing.objects.filter(school_id=school_id).exists():
#         for i in name:
#             llt = Grades.objects.create(school_id_id=school_id,name=i) 
#             llt.save()
#             return Response({"success":True, "message": "Grades added successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#     else:
#         return Response({"message": "School not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)
      
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def addgrades_forschool(request):
    school_id = request.data.get("school_id")
    names = request.data.get("name")

    if not school_id:
        return Response({"message": "School ID is required", "status": status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    if not Schools_listing.objects.filter(school_id=school_id).exists():
        return Response({"message": "School not found", "status": status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)

    if not names:
        return Response({"message": "No grade names provided", "status": status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    created_grades = []

    for grade_name in names.split(","):
        grade = Grades.objects.create(school_id_id=school_id, name=grade_name.strip())
        grade.save()
        created_grades.append(grade_name.strip())

    return Response(
        {"success": True, "message": "Grades added successfully", "status": status.HTTP_200_OK},
        status=status.HTTP_200_OK
    )

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def editgrades_forschool(request):
    if request.data['grades_id'] == "":
        return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    grades_id = request.data['grades_id']
    user = Grades.objects.filter(grades_id=grades_id).first()
    if user:
        school_id = request.data["school_id"]
        name = request.data["name"]
    if school_id:
        user.school_id_id= school_id
    if name:
        user.name = name
        user.save() 
        return Response({"success":True, "message": "Grades updated successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({'message': "Grade not found"}, status=status.HTTP_400_BAD_REQUEST)
      
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def deletegrade_forschool(request):
    if request.data['grades_id'] == "":
        return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    grades_id = request.data['grades_id']
    if Grades.objects.filter(grades_id=grades_id).exists():
        user = Grades.objects.filter(grades_id=grades_id).first()
        user.delete()
        return Response({"success":True, "message": "grade details deleted successfully","status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def allgrades_listing_forschool(request):
    if request.data['school_id'] == "":
        return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    school_id = request.data['school_id']
    if Schools_listing.objects.filter(school_id=school_id).exists():
        school_name = Schools_listing.objects.filter(school_id=school_id).first()
    if Grades.objects.filter(school_id=school_id).exists():
        if (Grades.objects.filter(school_id=school_id)):
            ldtt = Grades.objects.filter(school_id=school_id)
            serializer = GradeswithschoolSerializer(ldtt,many=True)
            x = serializer.data
            dict = {"school_id":school_id,"school_name":ldtt.first().school_id.school_name}
            return Response({"success":True, "message": "Here is your grade listing","data":x,"school_detail":dict,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
        else:
             return Response({"success":True, "message": "No Grades added !","data":x,"school_detail":dict,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        dict = {"school_id":school_id,"school_name":school_name.school_name}
        return Response({"message": "No Grade found ","school_detail":dict,"status":status.HTTP_200_OK}, status=status.HTTP_200_OK)       
           
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def kidslisting_according_grades(request):
    if request.data['grades_id'] == "":
        return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    grades_id = request.data['grades_id']
    if Grades.objects.filter(grades_id=grades_id).exists():
        user = Grades.objects.filter(grades_id=grades_id).first()
        try:
            kk = Kids_profile.objects.filter(grades_id = user)
        except Kids_profile.DoesNotExists():
            kk = None
            return Response({"success":False , "message":"No Kids Found"} ,status=status.HTTP_400_BAD_REQUEST)
        if not len(kk)>=1:
            return Response({"success":False , "message":"No Kids Found"} ,status=status.HTTP_400_BAD_REQUEST)
        
        for i in kk:
            if i is not None:
                if i.kid_full_name == None or i.kid_full_name == "":
                    return Response({"success":False , "message":"No Kids Found"} ,status=status.HTTP_400_BAD_REQUEST)
                
        serializer = kidslistingwithgradesSerializer(user)
        return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def single_grade_info(request):
    if request.data['grades_id'] == "":
        return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    grades_id = request.data['grades_id']
    if Grades.objects.filter(grades_id=grades_id).exists():
        user = Grades.objects.filter(grades_id=grades_id).first()
        serializer = GradesSerializer(user)
        return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
      

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def kidslisting_according_grades(request):
    if request.data['grades_id'] == "":
        return Response({"success":False, "message": "grades_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    grades_id = request.data['grades_id']
    if Grades.objects.filter(grades_id=grades_id).exists():
        user = Grades.objects.filter(grades_id=grades_id).first()
        serializer = kidslistingwithgradesSerializer(user)
        return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "grade details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
      

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def palns_according_to_grade(request):
    if request.data['grades_id']=="":
        return Response({"success":False, "message": "grades_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    grades_id = request.data['grades_id']
    ltt = Grades.objects.filter(grades_id=grades_id).first()
    serializer = GradewithplansSerializer(ltt)
    x = serializer.data
    return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
  

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def student_with_parents(request):
    if request.data['kds_profile_id']=="":
        return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    kds_profile_id = request.data['kds_profile_id']
    ltt = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
    serializer = StudentswithparentsSerializer(ltt)
    x = serializer.data
    return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
       

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def all_userdata(request):
    if Super.objects.all().exists:
        data = Super.objects.all()
        serializer = adddataSerializer(data,many=True)
        x = serializer.data
        return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Data not found"}, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def allpurchaseplans_listing(request):   
    gt = Selected_plans.objects.all().order_by("-selected_plans_id")
    serializer = SelectedplansSerializer(gt, many=True)
    x = serializer.data
    return Response({"success":True, "message": "Here is your purchase plan listing","data":x,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
      

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def singlebuypaln_info(request):
    if request.data['selected_plans_id'] == "":
        return Response({"success":False, "message": "selected_plans_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    selected_plans_id = request.data['selected_plans_id']
    if Selected_plans.objects.filter(selected_plans_id=selected_plans_id).exists():
        user = Selected_plans.objects.filter(selected_plans_id=selected_plans_id).first()
        serializer = SelectedplansSerializer(user)
        return Response({"success":True, "message": "Here is your data","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "plan details does'nt exist or invalid grade id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
      
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def allpurchasplans_status(request):
    if request.data['selected_plans_id']=="":
        return Response({"success":False, "message": "Plan Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    selected_plans_id = request.data['selected_plans_id']
    try:
        gt = Selected_plans.objects.filter(selected_plans_id = selected_plans_id).first()
    except Selected_plans.DoesNotExist:
        gt = None
        return Response({"success":False , "message":"No Selected plan found" } , status= status.HTTP_400_BAD_REQUEST)
    
    if not gt == None:
        if gt.plan_status == 0:
            # ( Change staus deactive)
            gt.plan_status = 1
        elif gt.plan_status == 1:
            # (change status active)
            gt.plan_status = 0
        gt.save() 
        plans = SelectedplansStatusSerializer(gt)
        return Response({"success":True , "message":"Here Is all plans lisnting" , "data":plans.data} , status=status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No plan found" } , status=status.HTTP_400_BAD_REQUEST)
   
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def allpurchase_plans(request):
    try:
        plans = Selected_plans.objects.filter(plan_status=1).order_by("-selected_plans_id")
    except Selected_plans.DoesNotExist:
        plans = None
        return Response({"success" :True , "message":"No Active Plan Found" },status=status.HTTP_400_BAD_REQUEST)
    
    if plans is not None and len(plans)>=1:
        serializer = allpurchaseplansserializer(plans , many= True)
        x = serializer.data
        return Response({"success" :True , "message":"Here is all purchase plans" , "data":x},status=status.HTTP_200_OK)
    else:
        return Response({"success" :True , "message":"No Active Plan Found" },status=status.HTTP_400_BAD_REQUEST)
    
from datetime import datetime , timedelta
@api_view(['POST'])
@permission_classes([IsAuthenticated])   
def allpurchase_plans_sort(request):
    if request.data['data']=="":
        return Response({"success":False, "message": "Plan Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    data = request.data['data']
    
    try:
        plans = Selected_plans.objects.filter(plan_status=1).order_by("-selected_plans_id")
    except Selected_plans.DoesNotExist:
        plans = None
        return Response({"success":False , "message":"No Active Plan Found"} , status=status.HTTP_400_BAD_REQUEST)
    
    if len(plans)>= 1 and plans != None:
        today = datetime.today()
        current_date = datetime.now()
        last_day = today-timedelta(days=1)
        print(plans)
        
        first_day_of_current_month = current_date.replace(day=1)
        
        # ( last month date )
        last_day_of_last_month = first_day_of_current_month - timedelta(days=1)
        first_day_of_last_month = last_day_of_last_month-timedelta(days=30)
        
        # ( last Week date ) 
        end_date_of_last_week = current_date - timedelta(days=current_date.weekday() + 1)  # End of previous week
        start_date_of_last_week = end_date_of_last_week - timedelta(days=6) 
        
        # ( last year data )
        end_date_of_last_year = current_date.replace(year=current_date.year - 1, month=12, day=31)
        start_date_of_last_year = end_date_of_last_year.replace(day=1, month=1)
        
        if data == "month":
            try:
                sort_data = plans.filter(
                    Q(plan_id__start_date__gte = first_day_of_last_month ) & Q(plan_id__start_date__lte= last_day_of_last_month))
            except Selected_plans.DoesNotExist:
                sort_data = None
        
        if data == "week":
            try:
                sort_data = plans.filter(
                    Q(plan_id__start_date__gte = start_date_of_last_week ) & Q(plan_id__start_date__lte= end_date_of_last_week))
            except Selected_plans.DoesNotExist:
                sort_data = None
                
        
        if data == "year":
            try:
                sort_data = plans.filter(
                    Q(plan_id__start_date__gte = start_date_of_last_year ) & Q(plan_id__start_date__lte= last_day))
            except Selected_plans.DoesNotExist:
                sort_data = None
        
        if data == "last_day":
            try:
                sort_data = plans.filter(
                    Q(plan_id__start_date = last_day ))
            except Selected_plans.DoesNotExist:
                sort_data = None

        
        if sort_data is not None and len(sort_data)>=1:
            sorted_data = SelectedplansSerializer(sort_data , many= True).data
            return Response({"success":True , "message":"Your membership Plan here." , "data":sorted_data ,} , status=status.HTTP_200_OK)
        else:
            return Response({"success":False , "message":"No  Plan Found"} , status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response({"success":False , "message":"No  Plan Found"} , status=status.HTTP_400_BAD_REQUEST)

# from datetime import datetime , timedelta
# @api_view(['GET'])
# @permission_classes([IsAuthenticated])   
# def allpurchase_plans_sort(request):
#     try:
#         plans = Selected_plans.objects.filter(plan_status=1).order_by("-selected_plans_id")
#     except Selected_plans.DoesNotExist:
#         plans = None
#         return Response({"success":False , "message":"No Active Plan Found"} , status=status.HTTP_400_BAD_REQUEST)
    
#     if len(plans)>= 1 and plans != None:
#         today = datetime.today()
#         current_date = datetime.now()
#         last_day = today-timedelta(days=1)
        
#         first_day_of_current_month = current_date.replace(day=1)
        
#         # ( last month date )
#         last_day_of_last_month = first_day_of_current_month - timedelta(days=1)
#         first_day_of_last_month = last_day_of_last_month-timedelta(days=30)
#         print(last_day_of_last_month ,first_day_of_last_month )
        
#         # ( last Week date ) 
#         end_date_of_last_week = current_date - timedelta(days=current_date.weekday() + 1)  # End of previous week
#         start_date_of_last_week = end_date_of_last_week - timedelta(days=6) 
        
#         # ( last year data )
#         end_date_of_last_year = current_date.replace(year=current_date.year - 1, month=12, day=31)
#         start_date_of_last_year = end_date_of_last_year.replace(day=1, month=1)
        
#         monthly_sort = plans.filter(
#             Q(plan_id__start_date__gte = first_day_of_last_month ) & Q(plan_id__start_date__lte= last_day_of_last_month))
#         print(monthly_sort, "!!!!!!!!!!!!!!!!!!!!!!!!!")
        
#         weekly_sort = plans.filter(
#             Q(plan_id__start_date__gte = start_date_of_last_week ) & Q(plan_id__start_date__lte= end_date_of_last_week))
        
#         yearly_sort = plans.filter(
#             Q(plan_id__start_date__gte = start_date_of_last_year ) & Q(plan_id__start_date__lte= last_day))
        
#         lastday_sort = plans.filter(
#             Q(plan_id__start_date = last_day ))
        
#         m = SelectedplansSerializer(monthly_sort , many= True).data
#         w = SelectedplansSerializer(weekly_sort , many= True).data
#         y = SelectedplansSerializer(yearly_sort , many= True).data
#         l = SelectedplansSerializer(lastday_sort , many= True).data
#         return Response({"success":True , "message":"Your membership Plan here." , "data-m":m , "data-w":w , "data-y":y , "data-l":l } , status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False , "message":"No Active Plan Found"} , status=status.HTTP_400_BAD_REQUEST)
        
#     currentData = datetime.today()
#     ex_plans = Selected_plans.objects.filter(Q(expiry_date__lte=currentData))
#     for pls in ex_plans:
#         pls.plan_expire_status = 1
#         pls.save()
#     try:
#         plans = Selected_plans.objects.filter(plan_expire_status=1).order_by("-selected_plans_id")
#     except Selected_plans.DoesNotExist:
#         plans = None
#         return Response({"success":False , "message":"No Expired Plans."   } , status=status.HTTP_400_BAD_REQUEST)
#     if plans != None and len(plans)>= 1:
#         pp = SelectedplansSerializer(plans , many=True).data
#         return Response({"success":True , "message":"Expired membership Plan here." , "data":pp  } , status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False , "message":"No Expired Plans."   } , status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def allpurchase_plan_expire(request):
    if request.data['selected_plans_id']=="":
        return Response({"success":False, "message": "Plan Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    selected_plans_id = request.data['selected_plans_id']
    try:
        Plan =Selected_plans.objects.filter(selected_plans_id = selected_plans_id).first()
    except Selected_plans.DoesNotExist:
        Plan = None
        return Response({"success":False, "message": "No Active Plan Found"}, status=status.HTTP_400_BAD_REQUEST)
    
    if Plan is not None: 
        Plan.plan_expire_status = 1
        Plan.save()
        p = SelectedplansSerializer(Plan).data
        return Response({"success":True , "message":"Plan Expired" , "data":p} , status=status.HTTP_201_CREATED)
    else:
        return Response({"success":False, "message": "No Active Plan Found"}, status=status.HTTP_400_BAD_REQUEST)
     

@api_view(['GET'])
@permission_classes([IsAuthenticated]) 
def allpurchase_expiry_plans(request):
    current_datetime = timezone.now()
    sp_plans = Selected_plans.objects.all()
    mb_plans = Membership_plan.objects.filter(expiry_date__lt=current_datetime)
    for exp_pls in mb_plans:
        exp = sp_plans.filter(plan_id = exp_pls.plan_id).first()
        exp.plan_expire_status = 1
        exp.save()
    try:
        plans = Selected_plans.objects.filter(plan_expire_status=1).order_by("-selected_plans_id")
    except Selected_plans.DoesNotExist:
        plans = None
        return Response({"success":False , "message":"No Expired Plans."   } , status=status.HTTP_400_BAD_REQUEST)
    print(plans , "!!!!!!!!!!!!")
    if plans != None and len(plans)>= 1:
        pp = SelectedplansSerializer(plans , many=True).data
        return Response({"success":True , "message":"Expired membership Plan here." , "data":pp  } , status=status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No Expired Plans."   } , status=status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
@permission_classes([IsAuthenticated])     
def allpurchase_expireplan_active(request):
    if request.data['selected_plans_id']=="":
        return Response({"success":False, "message": "Plan Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    selected_plans_id = request.data['selected_plans_id']
    try:
        Plan =Selected_plans.objects.filter(selected_plans_id = selected_plans_id).first()
    except Selected_plans.DoesNotExist:
        Plan = None
        return Response({"success":False, "message": "No Disabled Plan Found"}, status=status.HTTP_400_BAD_REQUEST)
    
    if Plan is not None: 
        Plan.plan_expire_status = 0
        Plan.save()
        p = SelectedplansStatusSerializer(Plan).data
        return Response({"success":True , "message":"Plan Activated" , "data":p} , status=status.HTTP_201_CREATED)
    else:
        return Response({"success":False, "message": "No Disabled Plan Found"}, status=status.HTTP_400_BAD_REQUEST)




# # @api_view(['POST'])
# # def user_login(request):
# #     if request.data['username_Code'] == "":
# #         return Response({"success": False, "message": "username_Code is required"}, status=status.HTTP_400_BAD_REQUEST)
# #     username_Code = request.data['username_Code']
# #     if request.data['password'] == "":
# #         return Response({"success": False, "message": "password is required"}, status=status.HTTP_400_BAD_REQUEST)
# #     password = request.data['password']
    
# #     # Assuming you have already imported RefreshToken    
# #     if Myprofile.objects.filter(username_Code=username_Code, password=password).exists():
# #         user = Myprofile.objects.filter(username_Code=username_Code).first()
# #         profile_id = user.profile_id

# #         # Generate a RefreshToken for the user (similar to your LoginApi)
# #         refresh = RefreshToken.for_user(user)
# #         access_token = str(refresh.access_token)

# #         # Your existing token generation logic
# #         gogogo = {
# #             'profile_id': profile_id,
# #             'exp': datetime.utcnow() + timedelta(days=365),
# #             'iat': datetime.utcnow()
# #         }
# #         token = jwt.encode(gogogo, 'secret', algorithm='HS256')
        
        
# #         serializer = MyprofilesSerializer(user)
        
# #         return Response({
# #             "success": True,
# #             "message": "Logged In Successfully",
# #             'token': token,  # Use the access token from RefreshToken
# #             "data": serializer.data
# #         }, status=status.HTTP_200_OK)
# #     else:
# #         return Response({"success": False, "message": "Please Enter Valid Username or Password"}, status=status.HTTP_401_UNAUTHORIZED)


class UserLogin(APIView):
    serializer_class = LoginSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        username_Code = data['username_Code']
        password = data['password']

        try:
            user = get_user_model().objects.get(username_Code=username_Code)
        except get_user_model().DoesNotExist:
            return Response({
                "success": False, 
                "message": "User does not exist",
            }, status=status.HTTP_404_NOT_FOUND)

        if user.is_superuser:
            return Response({
                "success": False,
                "message": "Superusers are not allowed to log in.",
            }, status=status.HTTP_403_FORBIDDEN)

        if check_password(password, user.password):
            user.last_login = timezone.now()
            user.save()
            refresh = RefreshToken.for_user(user)
            access_token = str(refresh.access_token)
            refresh_token = str(refresh)

            return Response({
                "success": True, 
                "message": "Logged In Successfully",
                "user": MyprofilesSerializer(user, context={'request': request}).data,
                "access_token": access_token,
                "refresh_token": refresh_token,
            })
        else:
            return Response({
                "success": False,
                "message": "Invalid credentials",
            }, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['GET'])
@permission_classes([IsAuthenticated]) 
def get_user(request):
        user_id=request.user.id
        user = User.objects.filter(id=user_id).first()
        serializer = MyprofilesSerializer(user)
        x = serializer.data
        return Response({"success":True, "message": "Here is your profile","data":x}, status=status.HTTP_200_OK)
    

@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def basic_information(request):
    user_id=request.user.id
    user = User.objects.get(id=user_id)
    profile_pic = request.data["profile_pic"]
    full_name = request.data["full_name"] 
    email = request.data['email']
    contact_no = request.data['contact_no']
    user_status = request.data['user_status']
    if profile_pic:
        if "/" in profile_pic:
            profile_pic = profile_pic
        else:
            user.profile_pic = profile_pic
    if full_name:
        user.full_name = full_name
    if email:
        user.email = email
    if contact_no:
        user.contact_no =contact_no
    if user_status:
        user.status = user_status
        user.save()
        id = user.id
        user = User.objects.get(id=user_id)
        serializer = MyprofilesSerializer(user)
        return Response({"success":True, "message": "Your profile is completed successfully","data":serializer.data},status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Please enter valid Token id"},status=status.HTTP_401_UNAUTHORIZED)          


@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def kids_information(request):
    user_id=request.user.id
    school_id = request.data['school_id']
    grades_id = request.data['grades_id']
    kid_profile_pic = request.data['kid_profile_pic']
    kid_full_name = request.data['kid_full_name']
    roll_no = request.data["roll_no"]
    dob = request.data['dob']
    bio = request.data['bio'] 
    user = Kids_profile.objects.create(profile_id_id=user_id,grades_id_id=grades_id,school_id_id=school_id,kid_profile_pic=kid_profile_pic,kid_full_name=kid_full_name,roll_no=roll_no,dob=dob,bio=bio)
    dtt = user.kds_profile_id
    serializer = KidsprofileSerializer(dtt)
    return Response({"success":True, "message": "kids details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    


# @api_view(["POST"])
# @permission_classes([IsAuthenticated]) 
# def edit_kids_information(request):
#     if request.data['kds_profile_id'] == "":
#         return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     kds_profile_id = request.data['kds_profile_id']
#     user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
#     school_id = request.data['school_id']
#     grades_id = request.data['grades_id']
#     kid_profile_pic = request.data['kid_profile_pic']
#     kid_full_name = request.data['kid_full_name']
#     roll_no = request.data["roll_no"]
#     dob = request.data['dob']
#     bio = request.data['bio']
#     if school_id:
#         user.school_id_id= school_id
#     if grades_id:
#         user.grades_id_id= grades_id
#     if kid_profile_pic:
#         if "/" in kid_profile_pic:
#             kid_profile_pic = kid_profile_pic
#         else:
#             user.kid_profile_pic = kid_profile_pic
#     if kid_full_name:
#         user.kid_full_name = kid_full_name
#     if roll_no:
#         user.roll_no = roll_no
#     if dob:
#         user.dob = dob
#     if bio:
#         user.bio = bio
#         user.save()
#         serializer = KidsprofileSerializer(user)
#         return Response({"success":True, "message": "kids details updated successfully","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "Please enter valid  Kidz Id"},status=status.HTTP_401_UNAUTHORIZED)          
@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def edit_kids_information(request):
    if 'kds_profile_id' not in request.data or request.data['kds_profile_id'] == "":
        return Response({"success": False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST) 

    kds_profile_id = request.data['kds_profile_id']
    user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()

    if user is not None:
        try:
            school_id = request.data.get('school_id')
            grades_id = request.data.get('grades_id')
            kid_profile_pic = request.data.get('kid_profile_pic')
            kid_full_name = request.data.get('kid_full_name')
            roll_no = request.data.get("roll_no")
            dob = request.data.get('dob')
            bio = request.data.get('bio')

            if school_id is not None:
                user.school_id_id = school_id
            if grades_id is not None:
                user.grades_id_id = grades_id
            if kid_profile_pic is not None:
                if "/" in kid_profile_pic:
                    kid_profile_pic = kid_profile_pic
                else:
                    user.kid_profile_pic = kid_profile_pic
            if kid_full_name is not None:
                user.kid_full_name = kid_full_name
            if roll_no is not None:
                user.roll_no = roll_no
            if dob is not None:
                user.dob = dob
            if bio is not None:
                user.bio = bio
                user.save()
                serializer = KidsprofileSerializer(user)
                return Response({"success": True, "message": "kids details updated successfully", "data": serializer.data, "status": status.HTTP_200_OK}, status=status.HTTP_200_OK)
            else:
                return Response({"success": False, "message": "Please enter valid Kidz Id"}, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({"success": False, "message": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    else:
        return Response({"success": False, "message": "Kidz profile not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
@permission_classes([IsAuthenticated]) 
def userschool_all_listing(request):
    gt = Schools_listing.objects.all().order_by('-school_id')
    lst =[]
    for i in gt:
        rrr = Kids_profile.objects.filter(school_id=i.school_id).count()
        serializer = SchoolslistingSerializer(i)
        x = serializer.data
        x.update({"student_count":rrr})
        lst.append(x)
            
        return Response({"success":True, "message": "Here is your school details","data":lst,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
           return Response({"message": "school not found","status":status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)




@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def number_of_kids_listing(request):
    user=request.user.id
    try:
        kids = Kids_profile.objects.filter(profile_id_id = request.user.id)
    except Kids_profile.DoesNotExists:
        kids = None
    
    if kids is not None and len(kids)>= 1:
        serializer  = KidsdataSerializer(kids , many=True)
        x = serializer.data
        if x:
            return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "Kids not found"}, status=status.HTTP_404_NOT_FOUND)
    else:
        return Response({"success":False, "message": "No Kids Added"}, status=status.HTTP_404_NOT_FOUND)
from django.http import JsonResponse  ,HttpResponse
@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def user_buy_plan(request):
    user = request.user
    profile_id  = user.id
    
    plan_id = request.data["plan_id"]
    kds_profile_id = request.data["kds_profile_id"]
    grades_id = request.data['grades_id']
    try:
        Kid = Kids_profile.objects.filter(kds_profile_id = kds_profile_id).first()
    except Kids_profile.DoesNotExists:
        Kid = None
    if Kid is not None:
        
        try:
            grades = Grades.objects.filter(grades_id = grades_id).first()
        except Grades.DoesNotExists:
            grades = None
        
        if grades is not None:
            
            try:    
                plan = Membership_plan.objects.filter(plan_id = plan_id).first()
            except Membership_plan.DoesNotExists:
                plan = None
                
            if plan is not None:
                duration = plan.duration_id
                plan_price = float(plan.plan_price)
                plan_name = plan.plan_name
                quantity = 1
                buyed_plan = Selected_plans.objects.create(plan_id_id = plan.plan_id , profile_id_id = request.user.id , kds_profile_id_id = Kid.kds_profile_id , school_id_id = Kid.school_id.school_id  , plan_expire_status = 0 , plan_status = 1  )
                buyed_plan.save()
                x = allpurchaseplansserializer(buyed_plan).data
                return Response({"success":True , "message":"Plan Buy Successfully" , "data":x} , status = status.HTTP_201_CREATED)
                
            else:
                return Response({"success":False , "message":"Plan does't have price Yet "} , status = status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"success":False , "message":"Grade not Found "} , status = status.HTTP_400_BAD_REQUEST)
        
    else:
         return Response({"success":False , "message":"No Kid Found "} , status = status.HTTP_400_BAD_REQUEST)   

@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def number_of_kids_listing(request):
    user=request.user.id
    kids = Kids_profile.objects.all()
    serializer  = KidsdataSerializer(kids , many=True)
    x = serializer.data
    if x:
        return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Kids not found"}, status=status.HTTP_404_NOT_FOUND)
    

@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def membership_listing(request):
    if request.data['school_id'] == "":
        return Response({"success":False, "message": "school_id is required","status":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST) 
    school_id = request.data['school_id']
    if Schools_listing.objects.filter(school_id=school_id).exists():
        ltt = Schools_listing.objects.filter(school_id=school_id).first()
    serializer = SchoolswithmembershiplistingSerializer(ltt)
    if serializer:
        return Response({"success":True, "message": "Here is your membership listing","data":serializer.data,"status":status.HTTP_200_OK},status=status.HTTP_200_OK)
    else:
        return Response({"message": "school does'nt exist or invalid school id","status":status.HTTP_404_NOT_FOUND},status=status.HTTP_404_NOT_FOUND)
     
    

@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def get_membership(request):
    user_id=request.user.id
    user = User.objects.get(id=user_id)
    if request.data['plan_id'] == "":
        return Response({"success":False, "message": "plan_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    plan_id = request.data['plan_id']
    if request.data['kds_profile_id'] == "":
        return Response({"success":False, "message": "kds_profile_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    kds_profile_id = request.data['kds_profile_id']
    fill = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()     
    fill.status = 1
    ldd = Selected_plans.objects.create(plan_id_id=plan_id,profile_id_id=request.user.id,kds_profile_id_id=kds_profile_id)
    ldd.save()
    return Response({"success":True,"message": "Plan has been added successfully."}, status=status.HTTP_200_OK)
       

@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def my_plan_listing(request):
    user_id=request.user
    plans = Selected_plans.objects.all()
    serializer = PlansSerializer(plans,many=True)
    # x = serializer.data
    return Response({"success":True, "message": "Here is your list","data":serializer.data}, status=status.HTTP_200_OK)
    # else:
    #         return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
   


@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def edit_profile(request):
    user_id=request.user.id
    user = User.objects.get(id=user_id)
    profile_pic = request.data["profile_pic"]
    full_name = request.data["full_name"] 
    email = request.data['email']
    expertise = request.data['expertise']
    contact_no = request.data['contact_no']
    if profile_pic:
        if "/" in profile_pic:
            profile_pic = profile_pic
        else:
            user.profile_pic = profile_pic
    if full_name:
        user.full_name = full_name
    if email:
        user.email = email
    if expertise:
        user.expertise = expertise
    if contact_no:
        user.contact_no = contact_no
        user.save()
        serializer = MyprofilesSerializer(user)
        x = serializer.data
        return Response({"success":True, "message": "Profile updated successfully","data":x}, status=status.HTTP_200_OK)
    else:
        return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)
  

@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def setting_password_change(request):
    user_id=request.user.id
    if request.data["old_password"]=="":
        return Response({"success":False, "message": "old_password is required" }, status=status.HTTP_400_BAD_REQUEST)
    old_password = request.data['old_password']
    if request.data['new_password']=="":
        return Response({"success":False, "message": "password is required" }, status=status.HTTP_400_BAD_REQUEST)
    new_password = request.data['new_password']
    if request.data['conferm_password']=="":
        return Response({"success":False, "message": "conferm password is required" }, status=status.HTTP_400_BAD_REQUEST)
    conferm_password = request.data['conferm_password']
    if User.objects.filter(id=user_id,password=old_password).exists():
        if new_password==conferm_password:
            mvp = User.objects.filter(id=user_id)
            mvp.password = new_password
            mvp.save()
            return Response({"success":True, "message": "Password changed successfully"}, status=status.HTTP_200_OK) 
        else:
                return Response({"success":False, "message": "password does'nt match properly"},status=status.HTTP_401_UNAUTHORIZED)         
    else:
        return Response({"success":False, "message": "old password is invalid"},status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def single_kid_information(request):
    if request.data['kds_profile_id']=="":
        return Response({"success":False, "message": "kid_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    kds_profile_id = request.data['kds_profile_id']
    user = Kids_profile.objects.filter(kds_profile_id=kds_profile_id).first()
    serializer = KidsprofileSerializer(user)
    x = serializer.data
    return Response({"success":True, "message": "Here is your profile","data":x}, status=status.HTTP_200_OK)
   

@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def forget_password(request):
    if request.data['email'] == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email = request.data['email']
    if User.objects.filter(email=email).exists():
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email]
        subject = "One Time OTP"
        otp = str(random.randint(1000, 9999))
        print(otp)
        message = "Your one time OTP is "
        ms=message + otp
        if Email_otp.objects.filter(email=email).exists():
            nttp = Email_otp.objects.filter(email=email).first()
            samma = timezone.now()
            nttp.otp = otp
            nttp.time = samma
            nttp.save()
        else:
            query = Email_otp(email=email,otp=otp,time=timezone.now())
            query.save()
        send_mail( subject, ms, email_from, recipient_list)
        return Response({"success":True, "message": "OTP send successfully"}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Invalid Email"}, status=status.HTTP_401_UNAUTHORIZED)
 

@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def verify_forget_pass(request):
    if request.data['otp'] == "":
        return Response({"success":False, "message": "Otp is required" }, status=status.HTTP_400_BAD_REQUEST) 
    otp = request.data['otp']
    if request.data['email'] == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email = request.data['email']
    if Email_otp.objects.filter(otp=otp,email=email):
        # ddty = Email_otp.objects.filter(otp=otp,email=email).first()
        # start_time = ddty.time
        # end_time = start_time + timedelta(minutes=int(5))
        # end_time = datetime.strftime(end_time, '%Y-%m-%d %H:%M:%S')
        # over = datetime.now()
        # over = datetime.strftime(over, '%Y-%m-%d %H:%M:%S')
        # if over >= end_time:
        #     return Response({"success":False, "message": "OTP Expired" }, status=status.HTTP_401_UNAUTHORIZED)
        
        return Response({"success":True, "message": "OTP verified successfully"}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "invalid OTP"}, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
@permission_classes([IsAuthenticated]) 
def create_new_password(request):
    if request.data['email'] == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email = request.data['email']
    if request.data['change_password']=="":
            return Response({"success":False, "message": "password is required" }, status=status.HTTP_400_BAD_REQUEST)
    change_password = request.data['change_password']
    if request.data['confirm_password']=="":
        return Response({"success":False, "message": "conferm password is required" }, status=status.HTTP_400_BAD_REQUEST)
    confirm_password = request.data['confirm_password']
    if User.objects.filter(email=email).first():
        if change_password==confirm_password:
            mvp = User.objects.filter(email=email).first()
            mvp.password = confirm_password
            mvp.save()
            return Response({"success":True, "message": "Password changed successfully"}, status=status.HTTP_200_OK) 
        else:
          return Response({"success":False, "message": "password does'nt match properly"},status=status.HTTP_401_UNAUTHORIZED)
    else:
        return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)



@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def school_with_grades(request):
    if request.data['school_id']=="":
        return Response({"success":False, "message": "school_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    school_id = request.data['school_id']
    ltt = Schools_listing.objects.filter(school_id=school_id).first()
    serializer = SchoolwithgradesSerializer(ltt)
    x = serializer.data
    if x:
        return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Kids not found"}, status=status.HTTP_404_NOT_FOUND)
   

@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def grade_with_planlisting(request):
    if request.data['grades_id']=="":
        return Response({"success":False, "message": "grades_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    grades_id = request.data['grades_id']
    ltt = Grades.objects.filter(grades_id=grades_id).first()
    serializer = GradewithplansSerializer(ltt)
    x = serializer.data
    if x:
        return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "parent not found"}, status=status.HTTP_404_NOT_FOUND)
   

@api_view(["POST"])
@permission_classes([IsAuthenticated]) 
def get_plan_details(request):
    if request.data['plan_id']=="":
        return Response({"success":False, "message": "plan_id is required" }, status=status.HTTP_400_BAD_REQUEST)
    plan_id = request.data['plan_id']
    if (Membership_plan.objects.filter(plan_id=plan_id).exists()):
        ltt = Membership_plan.objects.filter(plan_id=plan_id).first()
    else:
        ltt = None
    
    if ltt is not None :
        serializer = MembershipplansSerializer(ltt)
        x = serializer.data
        if x:
            return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "parent not found"}, status=status.HTTP_404_NOT_FOUND)
    else:
        return Response({"success":False, "message": "Plan not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@permission_classes([IsAuthenticated])  
def single_purchase_plan_info(request):
    if request.data['selected_plans_id']=="":
        return Response({"success":False, "message": "Plan Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    plans_id = request.data['selected_plans_id']
    try:
        plan = Selected_plans.objects.filter(selected_plans_id= plans_id).first()
    except Selected_plans.DoesNotExist:
        plan = None
    if plan is not None:
        pp = SelectedplansSerializer(plan).data
        return Response({"success":True , "message":"Expired membership Plan here." , "data":pp  } , status=status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No Plan Found"   } , status=status.HTTP_400_BAD_REQUEST)   

@api_view(['POST'])
@permission_classes([IsAuthenticated])  
def single_expiry_plan_info(request):
    if request.data['selected_plans_id']=="":
        return Response({"success":False, "message": "Plan Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    plans_id = request.data['selected_plans_id']
    try:
        plan = Selected_plans.objects.filter(selected_plans_id= plans_id).first()
    except Selected_plans.DoesNotExist:
        plan = None
    if plan is not None:
        pp = SelectedplansSerializer(plan).data
        return Response({"success":True , "message":"Expired membership Plan here." , "data":pp  } , status=status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No Plan Found"   } , status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])  
def sort_data_filter(request):
    filters = [
         {
            "filter_id": 1,
            "filter_name": "month",
        },
        {
            "filter_id": 2,
            "filter_name": "year",
        },
         {
            "filter_id": 3,
            "filter_name": "week",
        },
        {
            "filter_id": 4,
            "filter_name": "last_day",
        }
    ]    
    return Response({
        "success":True , "message":"Sorted Filters Here" , "data":filters
    } , status = status.HTTP_201_CREATED)



@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_purchase_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id = user.id , plan_status = 1 , plan_expire_status=0 )
    except Selected_plans.DoesNotExist:
        plans = None
    print(plans)
    if plans is not None and len(plans)>= 1:
        pp = SelectedPlanGradeDurationSerializer(plans , many=True).data
        return Response({"success":True , "message":"Here is your Plans" , "data":pp} , status=status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No plans " } , status=status.HTTP_400_BAD_REQUEST)

@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_expiry_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = request.user.id , plan_expire_status=1 )
    except Selected_plans.DoesNotExist:
        plans = None
    print(plans)
    if plans is not None and len(plans)>= 1:
        pp = SelectedPlanGradeDurationSerializer(plans , many=True).data
        return Response({"success":True , "message":"Here is your Expired Plans" , "data":pp} , status=status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No plans " } , status=status.HTTP_400_BAD_REQUEST)
    
@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def user_purchase_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id = request.user.id)
    except Selected_plans.DoesNotExists:
        plans = None
     
    if plans is not None and len(plans)>= 1:
        x = SelectedPlanGradeDurationSerializer(plans , many=True).data 
        return Response({"success":True , "message":"here is your all Plans" , "data":x} , status = status.HTTP_200_OK)

@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_active_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id , plan_status = 1 , plan_expire_status = 0)
    except Selected_plans.DoesnotExists:
        plans = None
    
    if plans is not None and len(plans)>= 1:
        x = SelectedPlanGradeDurationSerializer(plans , many=True).data
        return Response({"success":True , "message":"here is your all Plans" , "data":x} , status = status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
 

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_user_expired_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id  , plan_expire_status = 1)
    except Selected_plans.DoesnotExists:
        plans = None
    
    if plans is not None and len(plans)>= 1:
        x = SelectedPlanGradeDurationSerializer(plans , many=True).data
        return Response({"success":True , "message":"here is your Expired Plans" , "data":x} , status = status.HTTP_200_OK)
    else:
        return Response({"success":False , "message":"No Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
    

# @api_view(["GET"])
# @permission_classes([IsAuthenticated]) 
# def number_of_kids_listing(request):
#     user=request.user.id
#     try:
#         kids = Kids_profile.objects.filter(profile_id_id = request.user.id)
#     except Kids_profile.DoesNotExists:
#         kids = None
    
#     if kids is not None and len(kids)>= 1:
#         serializer  = KidsdataSerializer(kids , many=True)
#         x = serializer.data
#         if x:
#             return Response({"success":True, "message": "Here is your list","data":x}, status=status.HTTP_200_OK)
#         else:
#             return Response({"success":False, "message": "Kids not found"}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({"success":False, "message": "No Kids Added"}, status=status.HTTP_404_NOT_FOUND)
 
     
@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_monthly_active_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id , plan_status = 1 , plan_expire_status = 0)
    except Selected_plans.DoesnotExists:
        plans = None
    
    
    if plans is not None and len(plans)>= 1:
        monthly_plans = plans.filter(plan_id__duration_id=2)
        if monthly_plans is not None and len(monthly_plans)>= 1:
            
            if (monthly_plans.filter(plan_status = 1).exists()):
                monthly_active_plans = monthly_plans.filter(plan_status = 1) # active plans 
                x = SelectedPlanGradeDurationSerializer(monthly_active_plans , many=True).data
                return Response({"success":True , "message":"here is your Monthly Active Plans" , "data":x} , status = status.HTTP_200_OK)
            else:
                return Response({"success":False , "message":"No Monthly Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
        
        else:
            return Response({"success":False , "message":"No Monthly Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
    else:
        return Response({"success":False , "message":"No monthly Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)


@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_daily_active_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id , plan_status = 1 , plan_expire_status = 0)
    except Selected_plans.DoesnotExists:
        plans = None
    
    
    if plans is not None and len(plans)>= 1:
        daily_plans = plans.filter(plan_id__duration_id=1)
        if daily_plans is not None and len(daily_plans)>= 1:
            
            if (daily_plans.filter(plan_status = 1).exists()):
                daily_active_plans = daily_plans.filter(plan_status = 1) # active plans 
                x = SelectedPlanGradeDurationSerializer(daily_active_plans , many=True).data
                return Response({"success":True , "message":"here is your Daily Active Plans" , "data":x} , status = status.HTTP_200_OK)
            else:
                return Response({"success":False , "message":"No Monthly Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
        
        else:
            return Response({"success":False , "message":"No Daily Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
    else:
        return Response({"success":False , "message":"No Daily Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_user_monthly_expired_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id  , plan_expire_status = 1)
    except Selected_plans.DoesnotExists:
        plans = None
    
    if plans is not None and len(plans)>= 1:
        monthly_plans = plans.filter(plan_id__duration_id=2)
        if monthly_plans is not None and len(monthly_plans)>= 1: 
            x = SelectedPlanGradeDurationSerializer(monthly_plans , many=True).data
            return Response({"success":True , "message":"here is your monthly Expired Plans" , "data":x} , status = status.HTTP_200_OK)
        else:
            return Response({"success":False , "message":"No Monthly Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
    else:
        return Response({"success":False , "message":"No Monthly Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_user_monthly_expired_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id  , plan_expire_status = 1)
    except Selected_plans.DoesnotExists:
        plans = None
    
    if plans is not None and len(plans)>= 1:
        monthly_plans = plans.filter(plan_id__duration_id=2)
        if monthly_plans is not None and len(monthly_plans)>= 1: 
            x = SelectedPlanGradeDurationSerializer(monthly_plans , many=True).data
            return Response({"success":True , "message":"here is your monthly Expired Plans" , "data":x} , status = status.HTTP_200_OK)
        else:
            return Response({"success":False , "message":"No Monthly Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
    else:
        return Response({"success":False , "message":"No Monthly Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_user_daily_expired_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id  , plan_expire_status = 1)
    except Selected_plans.DoesnotExists:
        plans = None
    
    if plans is not None and len(plans)>= 1:
        daily_plans = plans.filter(plan_id__duration_id=1)
        if daily_plans is not None and len(daily_plans)>=1:
            x = SelectedPlanGradeDurationSerializer(daily_plans , many=True).data
            return Response({"success":True , "message":"here is your Daily Expired Plans" , "data":x} , status = status.HTTP_200_OK)
        else:
            return Response({"success":False , "message":"No Daily Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)
    else:
        return Response({"success":False , "message":"No Daily Expired Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)


@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_daily_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id , plan_status = 1 , plan_expire_status = 0)
    except Selected_plans.DoesnotExists:
        plans = None
    
    
    if plans is not None and len(plans)>= 1:
        
        # monthly_plans = plans.filter(plan_id__duration_id=2)  # Monthly Plans
        daily_plans = plans.filter(plan_id__duration_id=1)   # Daily Plans 
        
        # Monthly Active plans 
        active_plans = daily_plans.filter(plan_status = 1 , plan_expire_status = 0) # active plans 
        expired_plans = daily_plans.filter(plan_expire_status= 1) # expired plans
        
        x = SelectedPlanGradeDurationSerializer(plans , many=True).data
        
        active_plans_count = active_plans.count()
        expired_plans_count = expired_plans.count()
        
        x.append({"daily_active_plans":active_plans_count})
        x.append({"daily_expired_plans" :expired_plans_count})
        
        return Response({"success":True , "message":"here is your Daily Active Plans" , "data":x} , status = status.HTTP_200_OK)

    else:
        return Response({"success":False , "message":"No Daily Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)


@api_view(["GET"])
@permission_classes([IsAuthenticated]) 
def get_user_monthly_plans(request):
    user = request.user
    try:
        plans = Selected_plans.objects.filter(profile_id_id = user.id , plan_status = 1 , plan_expire_status = 0)
    except Selected_plans.DoesnotExists:
        plans = None
    
    
    if plans is not None and len(plans)>= 1:
        
        monthly_plans = plans.filter(plan_id__duration_id=2)  # Monthly Plans
        # daily_plans = plans.filter(plan_id__duration_id=1)   # Daily Plans 
        
        # Monthly Active plans 
        active_plans = monthly_plans.filter(plan_status = 1 , plan_expire_status = 0) # active plans 
        expired_plans = monthly_plans.filter(plan_expire_status= 1) # expired plans
        
        x = SelectedPlanGradeDurationSerializer(plans , many=True).data
        
        active_plans_count = active_plans.count()
        expired_plans_count = expired_plans.count()
        
        x.append({"monthly_active_plans":active_plans_count})
        x.append({"monthly_expired_plans" :expired_plans_count})
        
        return Response({"success":True , "message":"here is your Monthly Active Plans" , "data":x} , status = status.HTTP_200_OK)

    else:
        return Response({"success":False , "message":"No monthly Active Plans  Found "} , status = status.HTTP_400_BAD_REQUEST)