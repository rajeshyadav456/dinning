from django.db import models
from django.contrib.auth.models import AbstractUser
from .manager import UserManager
from django.dispatch import receiver
from django.urls import reverse
from django_rest_passwordreset.signals import reset_password_token_created
from django.core.mail import send_mail  
from django.conf import settings
from django.utils.text import slugify
from django.utils.crypto import get_random_string

    
# class Users(AbstractUser):
#     username = models.CharField(unique=True, max_length=225)
#     password = models.CharField(max_length=200,null=True)
#     profile_pic = models.FileField(upload_to='UserProfileImages') 
#     full_name = models.CharField(max_length=100,null=True)
#     address = models.CharField(max_length=200,null=True)
#     email = models.EmailField(null=True)
#     country_code = models.CharField(max_length=200,null=True)
#     phone_number = models.CharField(max_length=20,null=True)
#     schoolkionly_id = models.CharField(max_length=200,null=True)
#     gradekionly_id = models.CharField(max_length=200,null=True)
#     profile_pic = models.FileField(upload_to="",default="")
#     full_name = models.CharField(max_length=200,null=True)
#     email = models.EmailField(null=True)
#     expertise = models.CharField(max_length=200,null=True)
#     contact_no = models.CharField(max_length=200,null=True)
#     username_Code = models.CharField(max_length=200,null=True)
#     firebase_token = models.CharField(max_length=1000,null=True)
#     date = models.DateTimeField(auto_now_add=True)
#     status = models.IntegerField(default=0)
   

#     USERNAME_FIELD = 'username'
#     REQUIRED_FIELDS = []
#     objects = UserManager()

 




class User(AbstractUser):
    # profile_id = models.AutoField(primary_key=True)
    username = models.CharField(unique=True, max_length=225)
    password = models.CharField(max_length=200,null=True)
    profile_pic = models.FileField(upload_to='UserProfileImages') 
    full_name = models.CharField(max_length=100,null=True)
    address = models.CharField(max_length=200,null=True)
    email = models.EmailField(null=True)
    country_code = models.CharField(max_length=200,null=True)
    phone_number = models.CharField(max_length=20,null=True)
    schoolkionly_id = models.CharField(max_length=200,null=True)
    gradekionly_id = models.CharField(max_length=200,null=True)
    profile_pic = models.FileField(upload_to="",default="")
    full_name = models.CharField(max_length=200,null=True)
    email = models.EmailField(null=True)
    expertise = models.CharField(max_length=200,null=True)
    contact_no = models.CharField(max_length=200,null=True)
    username_Code = models.CharField(max_length=200,null=True)
    firebase_token = models.CharField(max_length=1000,null=True)
    date = models.DateTimeField(auto_now_add=True)
    status = models.IntegerField(default=0)
   

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []
    objects = UserManager()




class Email_otp(models.Model):
    email_otp = models.AutoField(primary_key=True)
    email = models.EmailField()
    otp = models.CharField(max_length=15)
    time = models.DateTimeField(blank=True,null=True)

    def __str__(self):
        return f'{self.email} {self.otp}'





class Schools_listing(models.Model):
    school_id = models.AutoField(primary_key=True)
    school_name = models.CharField(max_length=100,null=True)
    image = models.FileField(upload_to='media/UserProfileImages')
    email = models.EmailField()
    country_code = models.CharField(max_length=200,null=True)
    contact_number = models.CharField(max_length=200,null=True)
    select_country = models.CharField(max_length=200,null=True)
    select_state  = models.CharField(max_length=200,null=True)
    select_city = models.CharField(max_length=200,null=True)
    postal_code = models.CharField(max_length=200,null=True)
    street_number = models.CharField(max_length=200,null=True)
    apartment_number = models.CharField(max_length=200,null=True)
    username_Code = models.CharField(max_length=200,null=True)


class Grades(models.Model):
    grades_id = models.AutoField(primary_key=True)
    school_id = models.ForeignKey(Schools_listing, on_delete=models.CASCADE,related_name="school_details_according_to_grade",null=True)
    name = models.CharField(max_length=200)


class Weeks(models.Model):
    weeks_id = models.AutoField(primary_key=True)
    week_days =  models.CharField(max_length=200)


class Grade_duration(models.Model):
    duration_id = models.AutoField(primary_key=True)
    days = models.CharField(max_length=200)


class Kids_profile(models.Model):
    kds_profile_id = models.AutoField(primary_key=True)
    profile_id = models.ForeignKey(User, on_delete=models.CASCADE,related_name="kids_detail",null=True)
    school_id = models.ForeignKey(Schools_listing, on_delete=models.CASCADE,related_name="school_details",null=True)
    grades_id = models.ForeignKey(Grades, on_delete=models.CASCADE,related_name="grades_for_student",null=True)
    # grades_id = models.ManyToManyField(Grades, related_name="grades_for_students", blank=True)  # ManyToManyField for multiple grades
    kid_profile_pic = models.FileField(upload_to="",default="")
    kid_full_name = models.CharField(max_length=200,null=True)
    roll_no = models.CharField(max_length=200,null=True)
    dob = models.DateField(blank=True,null=True)
    bio = models.CharField(max_length=200,null=True)
    username_Code = models.CharField(max_length=200,null=True)
    status = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.kds_profile_id} {self.kid_full_name}'




class Membership_plan(models.Model):
    plan_id = models.AutoField(primary_key=True)
    school_id = models.ForeignKey(Schools_listing, on_delete=models.CASCADE,related_name="plan_for_school",null=True)
    grades_id = models.ForeignKey(Grades, on_delete=models.CASCADE,related_name="gradedata",null=True) 
    plan_name = models.CharField(max_length=200,null=True)
    duration_id = models.ForeignKey(Grade_duration, on_delete=models.CASCADE,related_name="Grade_duration",null=True)
    plan_price = models.CharField(max_length=30,null=True)
    plan_Benefits_features = models.CharField(max_length=200,null=True)
    desc = models.CharField(max_length=500,null=True)
    recommended = models.IntegerField(default=0)
    date = models.DateTimeField(auto_now_add=True)
    start_date=models.DateField(null=True)
    expiry_date=models.DateField(null=True)
   
   
class Plans_available(models.Model):
    plan_available_id = models.AutoField(primary_key=True)
    plan_id = models.ForeignKey(Membership_plan, on_delete=models.CASCADE,related_name="plan_available_weekends",null=True)
    weeks_id = models.ForeignKey(Weeks, on_delete=models.CASCADE,related_name="Weeks",null=True)



class Selected_plans(models.Model):
    selected_plans_id = models.AutoField(primary_key=True)
    plan_id =  models.ForeignKey(Membership_plan, on_delete=models.CASCADE,related_name="plan",null=True)
    profile_id = models.ForeignKey(User, on_delete=models.CASCADE,related_name="parents_details",null=True)
    kds_profile_id = models.ForeignKey(Kids_profile, on_delete=models.CASCADE,related_name="kids_details",null=True)
    school_id = models.ForeignKey(Schools_listing, on_delete=models.CASCADE,related_name="school_data",null=True)
    plan_expire_status = models.IntegerField(default=0)
    datetime = models.DateTimeField(auto_now=True)
    plan_status = models.IntegerField(default=0)



# ==============================================================================

class Super(models.Model):
    super_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=200,null=True)
    password = models.CharField(max_length=200,null=True)
    profile_pic = models.FileField(upload_to='',default="") 
    full_name = models.CharField(max_length=100,null=True)
    address = models.CharField(max_length=200,null=True)
    email = models.EmailField(null=True)
    country_code = models.CharField(max_length=200,null=True)
    phone_number = models.CharField(max_length=20,null=True)
