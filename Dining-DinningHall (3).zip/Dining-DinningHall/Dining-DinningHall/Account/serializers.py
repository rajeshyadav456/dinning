from rest_framework import serializers
from .models import *
class LoginSerializer(serializers.Serializer):
    username_Code = serializers.CharField(max_length=200)
    password = serializers.CharField(max_length=200, required=False, allow_null=True)
    
class LoginDataSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=200)
    password = serializers.CharField(max_length=200, required=False, allow_null=True)

class UsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id",
            
        ]
        extra_kwargs = {
            'email':{'read_only': True},
           
        }
    def create(self, validated_data):
        profile_pic = validated_data.pop('profile_pic', None)
        user_image = Users.objects.create( **validated_data, profile_pic=improfile_pic)
        return user_image
    
    # def to_representation(self, instance):
    #     representation = super().to_representation(instance)
    #     if instance.profile_pic:
    #         representation['profile_pic'] = settings.SITE_DOMAIN + instance.profile_pic.url
    #     return representation

class MyprofilesSerializer(serializers.ModelSerializer):
    class Meta:
        model  = User
        fields = ('id','schoolkionly_id','gradekionly_id','profile_pic','full_name','email','expertise','contact_no','username_Code','firebase_token','date','status')


class KidsprofileSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Kids_profile
        fields = "__all__"
        depth = 1


class parentsandkidsdataSerializer(serializers.ModelSerializer):
    kids_detail = KidsprofileSerializer(many=True)
    class Meta:
        model  = User
        fields = ('id','schoolkionly_id','gradekionly_id','profile_pic','full_name','email','expertise','contact_no','username_Code','password','firebase_token','date','status','kids_detail')


class PlansavailableSerializer(serializers.ModelSerializer):
    class Meta:
       model  = Plans_available
       fields = "__all__"
       depth = 1



class MypurchasesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Selected_plans
        fields = "__all__"
        depth = 1


class SuperSerializer(serializers.ModelSerializer):
    class Meta:
        model  = User
        fields = ('schoolkionly_id','gradekionly_id','profile_pic','full_name','email','expertise','contact_no','username_Code','firebase_token','date','status')



class SchoolslistingSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Schools_listing
        fields = "__all__"




class WeeksSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Weeks
        fields = "__all__"


class GradesSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Grades
        fields = "__all__"
        depth = 1


class GradedurationSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Grade_duration
        fields = "__all__"
        

class GradeswithschoolSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Grades
        fields = "grades_id","name"


class SchoolwithgradesSerializer(serializers.ModelSerializer):
    school_details_according_to_grade = GradesSerializer(many=True)
    class Meta:
        model  = Schools_listing
        fields = "__all__"




class MembershipplansSerializer(serializers.ModelSerializer):
    plan_available_weekends = PlansavailableSerializer(many=True)
    class Meta:
        model  = Membership_plan
        fields = "__all__"
        depth = 1

class SchoolswithmembershiplistingSerializer(serializers.ModelSerializer):
    plan_for_school = MembershipplansSerializer(many=True)
    class Meta:
        model  = Schools_listing
        fields = "__all__"
        depth = 1


class GradewithplansSerializer(serializers.ModelSerializer):
    gradedata = MembershipplansSerializer(many=True)
    class Meta:
        model  = Grades
        fields = "__all__"


class kidslistingwithgradesSerializer(serializers.ModelSerializer):
    grades_for_student = KidsprofileSerializer(many=True)
    class Meta:
        model  = Grades
        fields = "__all__"


class PlansweeksavailableSerializer(serializers.ModelSerializer):
    plan_available_weekends = PlansavailableSerializer(many=True)
    school_id=SchoolslistingSerializer()
    grades_id=GradesSerializer()
    duration_id=GradedurationSerializer()
    class Meta:
        model  = Membership_plan
        fields = ("plan_id","school_id","grades_id","plan_name","duration_id","plan_price","plan_Benefits_features","desc","recommended","date","start_date","expiry_date","plan_available_weekends")


class GradeswithplanSerializer(serializers.ModelSerializer):
    plan_available_weekends = PlansavailableSerializer(many=True)
    class Meta:
        model  = Membership_plan
        fields = "__all__"


class StudentswithparentsSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Kids_profile
        fields = "__all__"
        depth = 1


class adddataSerializer(serializers.ModelSerializer):
    class Meta:
        model   = Super
        fields = "__all__"

class SelectedplansStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Selected_plans
        fields = "__all__"


class Membershipplanserilizer(serializers.ModelSerializer):
    class Meta:
        model = Membership_plan
        fields = "__all__"
        
class SelectedplansSerializer(serializers.ModelSerializer):
    plan_id = Membershipplanserilizer()
    profile_id = MyprofilesSerializer()
    kds_profile_id = KidsprofileSerializer()
    school_id = SchoolslistingSerializer()
    class Meta:
        model  = Selected_plans
        fields = ('selected_plans_id', 'plan_id', 'profile_id', 'kds_profile_id', 'school_id', 'plan_expire_status', 'datetime', 'plan_status')


class PlanslistingSerializer(serializers.ModelSerializer):
    parents_details = SelectedplansSerializer(many=True,read_only=True)
    class Meta:
        model  = User
        # fields = ('schoolkionly_id','gradekionly_id','profile_pic','full_name','email','expertise','contact_no','username_Code','firebase_token','date','status','parents_details')
        fields = "__all__"


class SelectedplanswithparentsSerializer(serializers.ModelSerializer):
    parents_details = SelectedplansSerializer(many=True)
    class Meta:
        model = User
        fields = ('schoolkionly_id','gradekionly_id','profile_pic','full_name','email','expertise','contact_no','username_Code','firebase_token','date','status')


        
class allpurchaseplansserializer(serializers.ModelSerializer):
    plan_id = Membershipplanserilizer()
    class Meta:
        model = Selected_plans
        fields = "__all__"
#updated serializer
class KidsdataSerializer(serializers.ModelSerializer):
    school_id=SchoolslistingSerializer()
    profile_id=MyprofilesSerializer()
    grades_id=GradesSerializer()
    class Meta:
        model = Kids_profile
        fields = "__all__"


class PlansSerializer(serializers.ModelSerializer):
    plan_id=Membershipplanserilizer()
    profile_id=MyprofilesSerializer()
    kds_profile_id=KidsprofileSerializer()
    school_id=SchoolslistingSerializer()
    class Meta:
        model = Selected_plans
        fields = "__all__"


class GradeDurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Grade_duration
        fields = "__all__"


class MembershipDurationPlanSerializer(serializers.ModelSerializer):
    duration_id = GradeDurationSerializer()
    class Meta:
        model = Membership_plan
        fields = "__all__"

class SelectedPlanGradeDurationSerializer(serializers.ModelSerializer):
    plan_id = MembershipDurationPlanSerializer()
    kds_profile_id = KidsprofileSerializer()
    class Meta:
        model = Selected_plans
        fields = "__all__"
       