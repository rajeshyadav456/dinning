from django.contrib import admin
from .models import *
# Register your models here.
# admin.site.register(Users)
admin.site.register(User)
admin.site.register(Email_otp)
admin.site.register(Schools_listing)
admin.site.register(Grades)
admin.site.register(Weeks)
admin.site.register(Grade_duration)
admin.site.register(Kids_profile)
admin.site.register(Membership_plan)
admin.site.register(Plans_available)
admin.site.register(Selected_plans)
